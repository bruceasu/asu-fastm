package net.sf.fastmweb;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import net.sf.fastm.TemplateLoader;

/**
 * <p>Title: Lightweb -- Light weight web layer</p>
 * <p>Description: Fast, Light weight</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author wang hailong
 * @version 1.0
 */

class TemplateMappingHandler
    extends DefaultHandler {

    static final Logger log = Logger.getLogger(TemplateMappingHandler.class.getName());

	String baseDir = "";

	public TemplateMappingHandler(String baseDir){
		this.baseDir = baseDir;
	}
	
    Map templateMap = new HashMap();

    /**
     * override DefaultHandler.startElement()
     *
     * @param namespaceURI
     * @param localName
     * @param qName
     * @param atts
     * @throws SAXException
     */
    public void startElement(String namespaceURI, String localName,
                             String qName,
                             Attributes atts) throws SAXException {

        // read "mapping" entry into the dispatch map
        if (qName.equals("template-mapping")) {
            String name = atts.getValue("name");
            String file = atts.getValue("file");

            if (name != null && file != null){
            	String realPath = baseDir + "/" + file;

				log.info("name = " + name + "; file = " + file);
            	
            	try{
					TemplateLoader templateLoader = new TemplateLoader(realPath);
					templateMap.put(name, templateLoader);
            	}catch(IOException e){
            		throw new SAXException(e);
            	}
            }
        }
    }

    /**
     *
     * @return
     */
    public Map getTemplateMap() {
        return templateMap;
    }
}
