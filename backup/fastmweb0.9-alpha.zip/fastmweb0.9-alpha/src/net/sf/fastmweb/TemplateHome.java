/*
 * Created on Jun 1, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package net.sf.fastmweb;

import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Logger;

import net.sf.fastm.ITemplate;
import net.sf.fastm.TemplateLoader;
import net.sf.fastm.IValueSet;

/**
 * @author warrenw
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class TemplateHome {
	static Logger log = Logger.getLogger(TemplateHome.class.getName());

	static volatile Map templateMap = null;

	/**
	 * 
	 * @param name
	 * @return
	 * @throws IOException
	 */
	public static TemplateLoader getTemplateLoader(String templateName){
		if(templateMap == null){
			throw new NullPointerException("template map is not init yet.");
		}
		
		TemplateLoader templateLoader = (TemplateLoader)templateMap.get(templateName);
		return templateLoader;
	}

	/**
	 * 
	 * @param webappDir
	 */
	public static void configByDir(String webappDir){
		configByDirFile(webappDir, webappDir + "/WEB-INF/template-mapping.xml");
	}

	/**
	 * 
	 * @param baseDir
	 * @param configFile
	 */
	public static void configByDirFile(String baseDir, String configFile){
		try{
			TemplateMappingHandler handler = new TemplateMappingHandler(baseDir);
			SAXParser saxParser = SAXParserFactory.newInstance().newSAXParser();
			saxParser.parse(configFile, handler);
			templateMap = handler.getTemplateMap();
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
}
