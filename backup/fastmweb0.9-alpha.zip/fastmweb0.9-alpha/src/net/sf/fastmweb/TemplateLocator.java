/*
 * Created on Jun 12, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package net.sf.fastmweb;

import net.sf.fastm.ITemplate;
import net.sf.fastm.TemplateLoader;
import net.sf.fastm.IValueSet;

import java.io.IOException;

/**
 * @author warrenw
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class TemplateLocator implements ITemplate {
	String pageName = null;
	volatile TemplateLoader templateLoader = null;

	/**
	 * 
	 * @param pageName
	 */
	public TemplateLocator(String pageName){
		this.pageName = pageName;
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	public TemplateLoader getTemplateLoader(){
		if(templateLoader == null){
			templateLoader = TemplateHome.getTemplateLoader(pageName);
		}
		if(templateLoader == null){
			throw new NullPointerException("template " + pageName + " is not configured.");
		}

		return templateLoader;
	}

	/**
	 * implements ITemplate
	 */
	public String toString(IValueSet valueSet){
		return getTemplateLoader().toString(valueSet);
	}

	/**
	 * 
	 * @param level
	 * @return
	 */    
	public String structure(int level){
		return getTemplateLoader().structure(level);
	}
}
