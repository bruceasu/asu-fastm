just like velocity-tools for velocity project.
fastmweb is a helper project for fastm project.
fastmweb can help config fastm templates in a web environment.

template-mapping.xml is a sample templates config file.
