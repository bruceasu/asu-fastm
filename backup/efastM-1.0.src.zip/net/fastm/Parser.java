/*     */ package net.fastm;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Category;
/*     */ 
/*     */ public class Parser
/*     */ {
/*  26 */   private static Category log = Category.getInstance(Parser.class.getName());
/*     */ 
/* 295 */   static final Pattern bgeinDynPattern = Pattern.compile("\\s*BEGIN\\s*DYNAMIC\\s*:\\s*.*\\s*");
/* 296 */   static final Pattern endDynPattern = Pattern.compile("\\s*END\\s*DYNAMIC\\s*:\\s*.*\\s*");
/* 297 */   static final Pattern beginIgnPattern = Pattern.compile("\\s*BEGIN\\s*IGNORED\\s*:\\s*.*\\s*");
/* 298 */   static final Pattern endIgnPattern = Pattern.compile("\\s*END\\s*IGNORED\\s*:\\s*.*\\s*");
/*     */ 
/* 301 */   static final Pattern bgeinDynPatternScript = Pattern.compile("\\s*//\\s*BEGIN\\s*DYNAMIC\\s*:\\s*.*\\s*");
/* 302 */   static final Pattern endDynPatternScript = Pattern.compile("\\s*//\\s*END\\s*DYNAMIC\\s*:\\s*.*\\s*");
/*     */ 
/* 306 */   static final Pattern[] patternGroup = { 
/* 307 */     bgeinDynPattern, 
/* 308 */     endDynPattern, 
/* 309 */     beginIgnPattern, 
/* 310 */     endIgnPattern };
/*     */ 
/* 314 */   static final int[] typeGroup = { 
/* 315 */     11, 
/* 316 */     21, 
/* 317 */     12, 
/* 318 */     22 };
/*     */   private static String PARSER_CONTEXT;
/*     */ 
/*     */   public static ITemplate parse(String fileName)
/*     */     throws IOException
/*     */   {
/*  35 */     return parse(fileName, "GBK");
/*     */   }
/*     */ 
/*     */   public static ITemplate parse(String fileName, String charsetName)
/*     */     throws IOException
/*     */   {
/*  48 */     if (log.isDebugEnabled()) {
/*  49 */       log.debug("start parsing " + fileName);
/*     */     }
/*  51 */     FileInputStream fileStream = new FileInputStream(fileName);
/*  52 */     ITemplate template = parse(fileStream, charsetName);
/*  53 */     fileStream.close();
/*     */ 
/*  55 */     return template;
/*     */   }
/*     */ 
/*     */   public static ITemplate parse(InputStream stream, String charsetName)
/*     */     throws IOException
/*     */   {
/*  66 */     if (charsetName == null) charsetName = "GBK";
/*     */ 
/*  68 */     InputStreamReader streamReader = new InputStreamReader(stream, charsetName);
/*  69 */     BufferedReader reader = new BufferedReader(streamReader);
/*     */ 
/*  71 */     ITemplate template = parse(reader);
/*  72 */     streamReader.close();
/*  73 */     reader.close();
/*  74 */     return template;
/*     */   }
/*     */ 
/*     */   public static ITemplate parse(BufferedReader reader)
/*     */     throws IOException
/*     */   {
/*  86 */     StringBuffer staticLines = new StringBuffer();
/*  87 */     Stack stack = new Stack();
/*  88 */     DynamicPart top = new DynamicPart("top");
/*     */ 
/*  90 */     StaticPart staticPart = null;
/*  91 */     String ignoredName = null;
/*  92 */     int lineNo = 0;
/*  93 */     List lineQueue = new LinkedList();
/*  94 */     boolean foundComment = false;
/*  95 */     String commentPart = null;
/*     */     while (true)
/*     */     {
/* 100 */       String line = null;
/* 101 */       if (commentPart != null) {
/* 102 */         line = commentPart;
/*     */       }
/* 104 */       else if (lineQueue.isEmpty()) {
/* 105 */         line = reader.readLine();
/* 106 */         lineNo++;
/*     */       } else {
/* 108 */         line = (String)lineQueue.remove(0);
/*     */       }
/*     */ 
/* 112 */       if (line == null)
/*     */         break;
/*     */       int commentBegin;
/* 114 */       if (commentPart != null) {
/* 115 */         commentPart = null;
/*     */       } else {
/* 117 */         commentBegin = line.indexOf("<!--");
/* 118 */         if (commentBegin >= 0) {
/* 119 */           String lineBefore = null;
/* 120 */           if (commentBegin > 0) {
/* 121 */             lineBefore = line.substring(0, commentBegin);
/*     */           }
/*     */ 
/* 124 */           StringBuffer commentBuf = new StringBuffer();
/*     */ 
/* 126 */           String commentLine = line;
/* 127 */           int commentEnd = commentLine.indexOf("-->");
/* 128 */           if (commentEnd < 0) {
/* 129 */             commentBuf.append(line.substring(commentBegin));
/* 130 */             commentBegin = 0;
/*     */           }
/*     */ 
/* 133 */           while (commentEnd < 0) {
/* 134 */             commentLine = reader.readLine();
/* 135 */             lineNo++;
/* 136 */             if (commentLine == null) break;
/* 137 */             commentEnd = commentLine.indexOf("-->");
/* 138 */             if (commentEnd >= 0) break;
/* 139 */             commentBuf.append(commentLine + "\n");
/*     */           }
/*     */ 
/* 142 */           if ((commentLine == null) || (commentEnd < 0)) {
/* 143 */             commentPart = commentBuf.toString();
/*     */           } else {
/* 145 */             int pos = commentEnd + "-->".length();
/* 146 */             String postfix = commentLine.substring(commentBegin, pos);
/* 147 */             commentBuf.append(postfix);
/*     */ 
/* 149 */             if (commentLine.length() > pos) {
/* 150 */               String lineAfter = commentLine.substring(pos);
/* 151 */               lineQueue.add(lineAfter);
/*     */             }
/*     */ 
/* 154 */             commentPart = commentBuf.toString();
/*     */           }
/*     */ 
/* 157 */           if (lineBefore != null) {
/* 158 */             line = lineBefore; break label362;
/*     */ 
/* 160 */             continue;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 166 */       label362: Token token = parseLine(line);
/*     */ 
/* 169 */       if (ignoredName != null)
/*     */       {
/* 171 */         if ((token.type == 22) && (ignoredName.equals(token.name))) {
/* 172 */           ignoredName = null; break label406;
/*     */ 
/* 174 */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 179 */       label406: if (token.type == 0) {
/* 180 */         staticLines.append(line + "\n");
/* 181 */         continue;
/*     */       }
/*     */ 
/* 185 */       if (staticLines.length() > 0)
/*     */       {
/* 187 */         staticPart = new StaticPart(staticLines.toString());
/* 188 */         top.addStep(staticPart);
/* 189 */         staticLines.setLength(0);
/*     */       }
/*     */ 
/* 192 */       switch (token.type) {
/*     */       case 12:
/* 194 */         ignoredName = token.name;
/* 195 */         break;
/*     */       case 11:
/* 201 */         DynamicPart dynamicPart = null;
/* 202 */         if (token.name.startsWith("CONDITION "))
/* 203 */           dynamicPart = new ConditionDynamicPart(token.name);
/*     */         else {
/* 205 */           dynamicPart = new DynamicPart(token.name);
/*     */         }
/*     */ 
/* 209 */         top.addStep(dynamicPart);
/*     */ 
/* 213 */         stack.push(top);
/* 214 */         top = dynamicPart;
/*     */ 
/* 216 */         break;
/*     */       case 21:
/* 219 */         if (!top.getName().equals(token.name)) {
/* 220 */           throw new IOException("line " + lineNo + ": End Dynamic: " + 
/* 221 */             top.getName() + " instead of " + token.name + " is expected.");
/*     */         }
/*     */ 
/* 225 */         top = (DynamicPart)stack.pop();
/* 226 */         if (top == null) {
/* 227 */           throw new IOException("line " + lineNo + ": End Dynamic: top = null, why?");
/*     */         }
/*     */ 
/*     */       case 5:
/* 231 */         List posPairs = token.posPairs;
/*     */ 
/* 237 */         if (posPairs == null) continue;
/* 238 */         int nPairs = posPairs.size();
/*     */ 
/* 240 */         int begin = 0;
/* 241 */         int end = line.length() - 1;
/*     */ 
/* 243 */         for (int k = 0; k < nPairs; k++) {
/* 244 */           PosPair posPair = (PosPair)posPairs.get(k);
/*     */ 
/* 246 */           if (begin < posPair.begin) {
/* 247 */             staticPart = 
/* 248 */               new StaticPart(line.substring(begin, posPair.begin));
/* 249 */             top.addStep(staticPart);
/*     */           }
/*     */ 
/* 253 */           String varName = line.substring(posPair.begin, posPair.end + 1);
/*     */           try
/*     */           {
/* 256 */             parseVariablePart(top, varName);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 260 */             e.printStackTrace();
/* 261 */             throw new IOException("分析variablePart失败");
/*     */           }
/*     */ 
/* 264 */           begin = posPair.end + 1;
/*     */         }
/*     */ 
/* 267 */         String tail = "\n";
/*     */ 
/* 269 */         if (begin <= end) {
/* 270 */           tail = line.substring(begin, end + 1) + "\n";
/*     */         }
/* 272 */         staticPart = new StaticPart(tail);
/* 273 */         top.addStep(staticPart);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 278 */     if (stack.size() > 0) {
/* 279 */       DynamicPart left = (DynamicPart)stack.pop();
/* 280 */       throw new IOException("line " + lineNo + ": END DYNAMIC:" + left.getName() + " is expected but not found.");
/*     */     }
/*     */ 
/* 283 */     if (staticLines.length() > 0) {
/* 284 */       staticPart = new StaticPart(staticLines.toString());
/* 285 */       top.addStep(staticPart);
/*     */     }
/*     */ 
/* 288 */     return top;
/*     */   }
/*     */ 
/*     */   public static Token parseLine(String line)
/*     */   {
/* 329 */     Token token = new Token();
/*     */ 
/* 332 */     if ((line.startsWith("<!--")) && (line.endsWith("-->"))) {
/* 333 */       int commentBeginPos = line.indexOf("<!--") + "<!--".length();
/* 334 */       int commentEndPos = line.indexOf("-->", commentBeginPos);
/*     */ 
/* 336 */       String tag = line.substring(commentBeginPos, commentEndPos).trim();
/*     */ 
/* 338 */       int nPatterns = patternGroup.length;
/* 339 */       for (int i = 0; i < nPatterns; i++) {
/* 340 */         Pattern pattern = patternGroup[i];
/* 341 */         if (pattern.matcher(tag).matches()) {
/* 342 */           token.type = typeGroup[i];
/* 343 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 347 */       if (token.type > 10) {
/* 348 */         int commaPos = tag.indexOf(":");
/* 349 */         token.name = tag.substring(commaPos + 1).trim();
/*     */       }
/*     */ 
/* 352 */       return token;
/*     */     }
/*     */ 
/* 357 */     if (bgeinDynPatternScript.matcher(line).matches()) {
/* 358 */       token.type = 11;
/* 359 */       int commaPos = line.indexOf(":");
/* 360 */       token.name = line.substring(commaPos + 1).trim();
/*     */ 
/* 362 */       return token;
/*     */     }
/*     */ 
/* 366 */     if (endDynPatternScript.matcher(line).matches()) {
/* 367 */       token.type = 21;
/* 368 */       int commaPos = line.indexOf(":");
/* 369 */       token.name = line.substring(commaPos + 1).trim();
/*     */ 
/* 371 */       return token;
/*     */     }
/*     */ 
/* 375 */     int begin = 0;
/* 376 */     List posPairs = null;
/*     */     while (true)
/*     */     {
/* 383 */       int lBracketPos = line.indexOf("{", begin);
/* 384 */       if (lBracketPos < 0)
/*     */         break;
/* 386 */       int rBracketPos = line.indexOf("}", lBracketPos);
/* 387 */       if (rBracketPos < 0) {
/*     */         break;
/*     */       }
/* 390 */       int nestedLeftBracketPos = line.indexOf("{", lBracketPos + 1);
/* 391 */       while ((nestedLeftBracketPos >= 0) && (nestedLeftBracketPos < rBracketPos)) {
/* 392 */         lBracketPos = nestedLeftBracketPos;
/* 393 */         nestedLeftBracketPos = line.indexOf("{", lBracketPos + 1);
/*     */       }
/*     */ 
/* 396 */       if (posPairs == null) {
/* 397 */         posPairs = new ArrayList();
/*     */       }
/*     */ 
/* 400 */       PosPair posPair = new PosPair();
/* 401 */       posPair.begin = lBracketPos;
/* 402 */       posPair.end = rBracketPos;
/*     */ 
/* 404 */       posPairs.add(posPair);
/*     */ 
/* 406 */       begin = rBracketPos + 1;
/*     */     }
/*     */ 
/* 409 */     if (posPairs != null) {
/* 410 */       token.type = 5;
/* 411 */       token.posPairs = posPairs;
/*     */     }
/*     */ 
/* 414 */     return token;
/*     */   }
/*     */ 
/*     */   public static String getPARSER_CONTEXT()
/*     */   {
/* 501 */     return PARSER_CONTEXT;
/*     */   }
/*     */ 
/*     */   public static void setPARSER_CONTEXT(String parser_context)
/*     */     throws IOException
/*     */   {
/* 508 */     File contextfile = new File(parser_context);
/* 509 */     if (!contextfile.exists())
/*     */     {
/* 511 */       throw new IOException("错误的解析器环境设置");
/*     */     }
/*     */ 
/* 514 */     PARSER_CONTEXT = parser_context;
/*     */   }
/*     */ 
/*     */   private static boolean isParserValid()
/*     */   {
/* 520 */     return PARSER_CONTEXT != null;
/*     */   }
/*     */ 
/*     */   private static void parseVariablePart(DynamicPart top, String vpartName)
/*     */     throws Exception
/*     */   {
/* 530 */     VariablePart varPart = null;
/*     */ 
/* 533 */     if (vpartName.startsWith("{global_"))
/*     */     {
/* 535 */       varPart = new GlobalVariablePart(vpartName);
/*     */ 
/* 538 */       top.addStep(varPart);
/*     */     }
/* 541 */     else if (vpartName.startsWith("{include "))
/*     */     {
/* 543 */       String filepath = getSubFilePath(vpartName);
/* 544 */       DynamicPart sub = (DynamicPart)parse(filepath);
/*     */ 
/* 547 */       List steps = top.getSteps();
/* 548 */       steps.addAll(sub.getSteps());
/* 549 */       top.setSteps(steps);
/*     */     }
/* 552 */     else if (vpartName.startsWith("{asChildInclude "))
/*     */     {
/* 554 */       String filepath = getSubFilePath(vpartName);
/* 555 */       String subDynaName = getSubDynaName(vpartName);
/* 556 */       DynamicPart sub = (DynamicPart)parse(filepath);
/*     */ 
/* 559 */       sub.setName(subDynaName);
/* 560 */       top.addStep(sub);
/*     */     }
/*     */     else
/*     */     {
/* 564 */       varPart = new VariablePart(vpartName);
/*     */ 
/* 567 */       top.addStep(varPart);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getSubFilePath(String vpartName)
/*     */     throws Exception
/*     */   {
/* 575 */     if (!isParserValid())
/*     */     {
/* 577 */       throw new IOException("无效的解析器设置 PARSER_CONTEXT没设置");
/*     */     }
/*     */ 
/* 580 */     String[] strarr = vpartName.split("(\\s)+");
/*     */ 
/* 582 */     if ((strarr.length != 2) && (strarr.length != 3))
/*     */     {
/* 584 */       throw new Exception("错误的 子模板包含格式，个元素之间用 空格 隔开");
/*     */     }
/*     */ 
/* 587 */     String retstr = strarr[(strarr.length - 1)];
/* 588 */     return PARSER_CONTEXT + File.separator + retstr.substring(0, retstr.length() - 1);
/*     */   }
/*     */ 
/*     */   private static String getSubDynaName(String vpartName)
/*     */     throws Exception
/*     */   {
/* 594 */     String[] strarr = vpartName.split("(\\s)+");
/*     */ 
/* 596 */     if ((strarr.length != 2) && (strarr.length != 3))
/*     */     {
/* 598 */       throw new Exception("错误的 子模板包含格式，个元素之间用 空格 隔开");
/*     */     }
/*     */ 
/* 601 */     return strarr[1];
/*     */   }
/*     */ 
/*     */   public static class Token
/*     */   {
/*     */     static final int Begin = 10;
/*     */     static final int End = 20;
/*     */     static final int Dynamic = 1;
/*     */     static final int Ingnored = 2;
/*     */     static final int BeginDynamic = 11;
/*     */     static final int EndDynamic = 21;
/*     */     static final int BeginIgnored = 12;
/*     */     static final int EndIgnored = 22;
/*     */     static final int HasVariable = 5;
/*     */     static final int Ordinary = 0;
/* 469 */     int type = 0;
/*     */ 
/* 474 */     String name = null;
/*     */ 
/* 479 */     List posPairs = null;
/*     */   }
/*     */ 
/*     */   static class PosPair
/*     */   {
/* 490 */     int begin = 0;
/* 491 */     int end = 0;
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.Parser
 * JD-Core Version:    0.6.0
 */