/*     */ package net.fastm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class ValueSet
/*     */   implements IValueSet
/*     */ {
/*  17 */   static final Logger log = Logger.getLogger(ValueSet.class.getName());
/*     */ 
/*  22 */   public static final IValueSet EMPTY_VALUESET = new ValueSet();
/*     */ 
/*  27 */   public static final List ONE_VALUESET_LIST = new ArrayList();
/*     */ 
/*  35 */   Map varMap = null;
/*     */ 
/*  40 */   Map dynMap = null;
/*     */ 
/*     */   static
/*     */   {
/*  30 */     ONE_VALUESET_LIST.add(EMPTY_VALUESET);
/*     */   }
/*     */ 
/*     */   public Object getVariable(String name)
/*     */   {
/*  49 */     if (this.varMap == null) {
/*  50 */       return null;
/*     */     }
/*     */ 
/*  53 */     return this.varMap.get(name);
/*     */   }
/*     */ 
/*     */   public void setVariable(String name, Object value)
/*     */   {
/*  63 */     if (this.varMap == null) {
/*  64 */       this.varMap = new HashMap();
/*     */     }
/*     */ 
/*  67 */     this.varMap.put(name, value);
/*     */   }
/*     */ 
/*     */   public List getDynamicValueSets(String name)
/*     */   {
/*  79 */     if ((name == null) || (this.dynMap == null)) {
/*  80 */       return null;
/*     */     }
/*     */ 
/*  83 */     return (List)this.dynMap.get(name);
/*     */   }
/*     */ 
/*     */   public void setDynamicValueSets(String name, List valueSets)
/*     */   {
/*  96 */     if ((valueSets == null) && (this.dynMap != null)) {
/*  97 */       this.dynMap.remove(name);
/*     */     }
/*     */ 
/* 100 */     if (this.dynMap == null) {
/* 101 */       this.dynMap = new HashMap();
/*     */     }
/*     */ 
/* 104 */     this.dynMap.put(name, valueSets);
/*     */   }
/*     */ 
/*     */   public void addDynamicValueSet(String name, IValueSet valueSet)
/*     */   {
/* 114 */     if (this.dynMap == null) {
/* 115 */       this.dynMap = new HashMap();
/*     */     }
/*     */ 
/* 118 */     List valueSets = (List)this.dynMap.get(name);
/* 119 */     if (valueSets == null) {
/* 120 */       valueSets = new ArrayList();
/* 121 */       this.dynMap.put(name, valueSets);
/*     */     }
/*     */ 
/* 124 */     valueSets.add(valueSet);
/*     */   }
/*     */ 
/*     */   public void setDynamicValueSet(String name, IValueSet valueSet)
/*     */   {
/* 137 */     List valueSets = null;
/* 138 */     if (valueSet != null) {
/* 139 */       valueSets = new ArrayList(1);
/* 140 */       valueSets.add(valueSet);
/*     */     }
/*     */ 
/* 143 */     setDynamicValueSets(name, valueSets);
/*     */   }
/*     */ 
/*     */   public Map getVariableMap()
/*     */   {
/* 149 */     return this.varMap;
/*     */   }
/*     */ 
/*     */   public Map getDynamicMap()
/*     */   {
/* 154 */     return this.dynMap;
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.ValueSet
 * JD-Core Version:    0.6.0
 */