/*    */ package net.fastm.interceptors;
/*    */ 
/*    */ import net.fastm.DefaultInterceptor;
/*    */ import net.fastm.IValueInterceptor;
/*    */ 
/*    */ public abstract class DelegatedInterceptor
/*    */   implements IValueInterceptor
/*    */ {
/*  9 */   protected IValueInterceptor delegator = DefaultInterceptor.instance;
/*    */ 
/* 11 */   public void setDelegator(IValueInterceptor delegator) { this.delegator = delegator; }
/*    */ 
/*    */   public Object getProperty(Object bean, String propertyName)
/*    */   {
/* 15 */     if (this.delegator == null) return null;
/* 16 */     Object value = this.delegator.getProperty(bean, propertyName);
/* 17 */     return getValue(bean, propertyName, value);
/*    */   }
/*    */ 
/*    */   protected abstract Object getValue(Object paramObject1, String paramString, Object paramObject2);
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.interceptors.DelegatedInterceptor
 * JD-Core Version:    0.6.0
 */