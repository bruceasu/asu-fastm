/*    */ package net.fastm.interceptors;
/*    */ 
/*    */ import net.fastm.IValueInterceptor;
/*    */ 
/*    */ public class ContextInterceptor extends DelegatedInterceptor
/*    */ {
/*    */   private Object context;
/*    */ 
/*    */   public void setContext(Object context)
/*    */   {
/* 11 */     this.context = context;
/*    */   }
/*    */ 
/*    */   protected Object getValue(Object bean, String propertyName, Object value) {
/* 15 */     if (value == null) value = this.delegator.getProperty(this.context, propertyName);
/* 16 */     return value;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.interceptors.ContextInterceptor
 * JD-Core Version:    0.6.0
 */