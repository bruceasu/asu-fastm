/*    */ package net.fastm.interceptors;
/*    */ 
/*    */ public class BooleanInterceptor extends DelegatedInterceptor
/*    */ {
/*    */   protected Object getValue(Object bean, String propertyName, Object value)
/*    */   {
/* 10 */     if ((value != null) && ((value instanceof Boolean))) {
/* 11 */       boolean b = ((Boolean)value).booleanValue();
/* 12 */       if (!b) return "";
/*    */     }
/* 14 */     return value;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.interceptors.BooleanInterceptor
 * JD-Core Version:    0.6.0
 */