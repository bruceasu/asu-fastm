/*    */ package net.fastm.interceptors;
/*    */ 
/*    */ public class NullInterceptor extends DelegatedInterceptor
/*    */ {
/*    */   protected Object getValue(Object bean, String propertyName, Object value)
/*    */   {
/*  5 */     if (value == null) {
/*  6 */       if (propertyName.startsWith("if_")) {
/*  7 */         return null;
/*    */       }
/*  9 */       return "";
/* 10 */     }return value;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.interceptors.NullInterceptor
 * JD-Core Version:    0.6.0
 */