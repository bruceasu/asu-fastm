package net.fastm;

public abstract interface IValueInterceptor
{
  public abstract Object getProperty(Object paramObject, String paramString);
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.IValueInterceptor
 * JD-Core Version:    0.6.0
 */