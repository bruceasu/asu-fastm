/*     */ package net.fastm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class TemplateLoader
/*     */   implements ITemplate
/*     */ {
/*  17 */   final Logger log = Logger.getLogger(getClass().getName());
/*     */ 
/*  22 */   String fileName = null;
/*     */ 
/*  27 */   volatile long fileTime = 0L;
/*     */ 
/*  32 */   volatile ITemplate template = null;
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  39 */     return this.fileName;
/*     */   }
/*     */ 
/*     */   public TemplateLoader(String fileName)
/*     */     throws IOException
/*     */   {
/*  49 */     this.fileName = fileName;
/*     */ 
/*  51 */     forceReload();
/*     */   }
/*     */ 
/*     */   public ITemplate getTemplate()
/*     */   {
/*  64 */     return this.template;
/*     */   }
/*     */ 
/*     */   public boolean fileChanged()
/*     */   {
/*  72 */     long theFiletime = new File(this.fileName).lastModified();
/*  73 */     return this.fileTime != theFiletime;
/*     */   }
/*     */ 
/*     */   public void forceReload()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       this.template = Parser.parse(this.fileName);
/*  84 */       this.fileTime = new File(this.fileName).lastModified();
/*     */     } catch (Exception e) {
/*  86 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void checkReload()
/*     */     throws IOException
/*     */   {
/*  94 */     if (fileChanged()) forceReload();
/*     */   }
/*     */ 
/*     */   public String toString(Object obj)
/*     */   {
/* 101 */     return getTemplate().toString(obj);
/*     */   }
/*     */ 
/*     */   public String toString(Object obj, IValueInterceptor valueInterceptor)
/*     */   {
/* 111 */     return getTemplate().toString(obj, valueInterceptor);
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer)
/*     */   {
/* 118 */     getTemplate().write(obj, writer);
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer, IValueInterceptor valueInterceptor)
/*     */   {
/* 128 */     getTemplate().write(obj, writer, valueInterceptor);
/*     */   }
/*     */ 
/*     */   public String structure(int level)
/*     */   {
/* 137 */     return getTemplate().structure(level);
/*     */   }
/*     */ 
/*     */   public static ITemplate getCachedTemplate(String name, String realPath, Map templateCache)
/*     */     throws IOException
/*     */   {
/* 150 */     TemplateLoader templateLoader = (TemplateLoader)templateCache.get(name);
/*     */ 
/* 152 */     if (templateLoader == null)
/*     */     {
/* 154 */       templateLoader = new TemplateLoader(realPath);
/* 155 */       templateCache.put(name, templateLoader);
/*     */     } else {
/* 157 */       templateLoader.checkReload();
/*     */     }
/*     */ 
/* 160 */     return templateLoader.getTemplate();
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.TemplateLoader
 * JD-Core Version:    0.6.0
 */