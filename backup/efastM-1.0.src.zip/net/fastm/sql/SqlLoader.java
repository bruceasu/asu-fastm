package net.fastm.sql;

public abstract interface SqlLoader
{
  public abstract SqlHolder load(Class paramClass, String paramString);
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlLoader
 * JD-Core Version:    0.6.0
 */