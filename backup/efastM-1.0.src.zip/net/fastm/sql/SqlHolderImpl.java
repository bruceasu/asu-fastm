/*    */ package net.fastm.sql;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import net.fastm.ITemplate;
/*    */ import net.util.BeanUtils;
/*    */ 
/*    */ class SqlHolderImpl
/*    */   implements SqlHolder
/*    */ {
/*    */   private String sql;
/*    */   private ITemplate sqlTemplate;
/* 30 */   private Map varMap = null;
/* 31 */   private int varCount = 0;
/*    */ 
/*    */   void setSql(String sql)
/*    */   {
/* 11 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public void setSqlTemplate(ITemplate template)
/*    */   {
/* 16 */     this.sqlTemplate = template;
/*    */   }
/*    */ 
/*    */   public SqlParam getSqlParam(Object data) {
/* 20 */     SqlParamImpl sqlParam = new SqlParamImpl();
/* 21 */     if (this.sql != null)
/* 22 */       sqlParam.setSql(this.sql);
/*    */     else {
/* 24 */       sqlParam.setSql(this.sqlTemplate.toString(data));
/*    */     }
/* 26 */     sqlParam.setParam(getParam(data));
/* 27 */     return sqlParam;
/*    */   }
/*    */ 
/*    */   void setVarMap(Map map, int count)
/*    */   {
/* 33 */     this.varMap = map;
/* 34 */     this.varCount = count;
/*    */   }
/*    */ 
/*    */   private Object getParam(Object data) {
/* 38 */     if ((this.varCount == 0) || (this.varMap == null)) return data;
/*    */ 
/* 40 */     Object[] parameters = new Object[this.varCount];
/*    */ 
/* 42 */     for (Iterator iterator = this.varMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 43 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 44 */       String name = entry.getKey().toString();
/* 45 */       int[] indice = (int[])entry.getValue();
/* 46 */       if (indice == null)
/*    */         continue;
/* 48 */       Object value = BeanUtils.getProperty(data, name);
/* 49 */       for (int i = 0; i < indice.length; i++) {
/* 50 */         int index = indice[i];
/* 51 */         parameters[index] = value;
/*    */       }
/*    */     }
/* 54 */     return parameters;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlHolderImpl
 * JD-Core Version:    0.6.0
 */