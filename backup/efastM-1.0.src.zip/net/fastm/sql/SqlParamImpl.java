/*    */ package net.fastm.sql;
/*    */ 
/*    */ class SqlParamImpl
/*    */   implements SqlParam
/*    */ {
/*    */   private Object sql;
/*    */   private Object param;
/*    */ 
/*    */   public Object getParam()
/*    */   {
/*  7 */     return this.param;
/*    */   }
/*    */   public void setParam(Object param) {
/* 10 */     this.param = param;
/*    */   }
/*    */   public Object getSql() {
/* 13 */     return this.sql;
/*    */   }
/*    */   public void setSql(Object sql) {
/* 16 */     this.sql = sql;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlParamImpl
 * JD-Core Version:    0.6.0
 */