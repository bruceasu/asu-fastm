/*     */ package net.fastm.sql;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.fastm.DynamicPart;
/*     */ import net.fastm.ITemplate;
/*     */ import net.fastm.Parser;
/*     */ import net.fastm.VariablePart;
/*     */ 
/*     */ public class SqlLoaderImpl
/*     */   implements SqlLoader
/*     */ {
/*     */   private static final String PARAM_TAG = "param:";
/*     */   private static final String TEXT_TAG = "text:";
/*     */ 
/*     */   public SqlHolder load(Class clazz, String resourceName)
/*     */   {
/*  25 */     InputStream inputStream = clazz.getClassLoader().getResourceAsStream(resourceName);
/*  26 */     if (inputStream == null) throw new RuntimeException("resource " + resourceName + " not exists in the class path");
/*     */ 
/*  28 */     return load(inputStream);
/*     */   }
/*     */ 
/*     */   public SqlHolder load(InputStream inputStream)
/*     */   {
/*  37 */     DynamicPart template = parse(inputStream);
/*  38 */     return load(template);
/*     */   }
/*     */ 
/*     */   public SqlHolder load(BufferedReader reader)
/*     */   {
/*  45 */     DynamicPart template = parse(reader);
/*  46 */     return load(template);
/*     */   }
/*     */ 
/*     */   public SqlHolder load(DynamicPart template)
/*     */   {
/*  55 */     List variables = template.getVariables();
/*  56 */     Map varMap = new HashMap();
/*  57 */     SqlHolderImpl sqlHolder = new SqlHolderImpl();
/*  58 */     int varCount = makeVarMap(variables, varMap);
/*  59 */     if (varCount > 0) {
/*  60 */       sqlHolder.setVarMap(varMap, varCount);
/*     */     }
/*     */ 
/*  63 */     int nTextPlaceHolders = processTextPlaceHolders(variables);
/*     */ 
/*  65 */     Map valueMap = makeValueMap(varMap);
/*  66 */     String sql = template.toString(valueMap);
/*     */ 
/*  68 */     if (nTextPlaceHolders == 0)
/*     */     {
/*  71 */       sqlHolder.setSql(sql);
/*     */     }
/*     */     else
/*     */     {
/*  76 */       StringReader strReader = new StringReader(sql);
/*  77 */       BufferedReader reader = new BufferedReader(strReader);
/*  78 */       ITemplate sqlTemplate = parse(reader);
/*  79 */       sqlHolder.setSqlTemplate(sqlTemplate);
/*     */     }
/*  81 */     return sqlHolder;
/*     */   }
/*     */ 
/*     */   private DynamicPart parse(InputStream inputStream)
/*     */   {
/*     */     try
/*     */     {
/*  91 */       DynamicPart template = (DynamicPart)Parser.parse(inputStream, "utf-8");
/*  92 */       return template; } catch (Exception e) {
/*     */     }
/*  94 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   private DynamicPart parse(BufferedReader reader)
/*     */   {
/*     */     try
/*     */     {
/* 105 */       DynamicPart template = (DynamicPart)Parser.parse(reader);
/* 106 */       return template; } catch (Exception e) {
/*     */     }
/* 108 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   private int makeVarMap(List variables, Map varMap)
/*     */   {
/* 118 */     if (variables == null) return 0;
/* 119 */     int n = variables.size();
/* 120 */     if (n == 0) return 0;
/*     */ 
/* 122 */     int count = 0;
/* 123 */     for (int i = 0; i < n; i++) {
/* 124 */       VariablePart var = (VariablePart)variables.get(i);
/* 125 */       String name = var.getPropName();
/* 126 */       if (!name.startsWith("param:"))
/*     */         continue;
/* 128 */       String key = name.substring("param:".length()).trim();
/* 129 */       var.setPropName(key);
/* 130 */       put(varMap, key, count);
/* 131 */       count++;
/*     */     }
/*     */ 
/* 134 */     return count;
/*     */   }
/*     */ 
/*     */   private int processTextPlaceHolders(List variables) {
/* 138 */     if (variables == null) return 0;
/* 139 */     int n = variables.size();
/* 140 */     if (n == 0) return 0;
/*     */ 
/* 142 */     int count = 0;
/* 143 */     for (int i = 0; i < n; i++) {
/* 144 */       VariablePart var = (VariablePart)variables.get(i);
/* 145 */       String name = var.getPropName();
/* 146 */       if (!name.startsWith("text:"))
/*     */         continue;
/* 148 */       String key = name.substring("text:".length()).trim();
/* 149 */       var.setPropName(key);
/* 150 */       count++;
/*     */     }
/*     */ 
/* 153 */     return count;
/*     */   }
/*     */ 
/*     */   private void put(Map map, Object key, int index)
/*     */   {
/* 164 */     int[] indice = (int[])map.get(key);
/* 165 */     if (indice == null) {
/* 166 */       indice = new int[] { index };
/*     */     } else {
/* 168 */       int n = indice.length;
/* 169 */       int[] newIndice = new int[n + 1];
/* 170 */       System.arraycopy(indice, 0, newIndice, 0, n);
/* 171 */       newIndice[n] = index;
/* 172 */       indice = newIndice;
/*     */     }
/* 174 */     map.put(key, indice);
/*     */   }
/*     */ 
/*     */   private Map makeValueMap(Map varMap)
/*     */   {
/* 183 */     if ((varMap == null) || (varMap.isEmpty())) {
/* 184 */       return Collections.EMPTY_MAP;
/*     */     }
/* 186 */     Map valueMap = new HashMap();
/* 187 */     for (Iterator iterator = varMap.keySet().iterator(); iterator.hasNext(); ) {
/* 188 */       Object key = iterator.next();
/* 189 */       valueMap.put(key, "?");
/*     */     }
/* 191 */     return valueMap;
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlLoaderImpl
 * JD-Core Version:    0.6.0
 */