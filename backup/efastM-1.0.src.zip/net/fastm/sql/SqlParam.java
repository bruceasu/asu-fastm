package net.fastm.sql;

public abstract interface SqlParam
{
  public abstract Object getSql();

  public abstract Object getParam();
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlParam
 * JD-Core Version:    0.6.0
 */