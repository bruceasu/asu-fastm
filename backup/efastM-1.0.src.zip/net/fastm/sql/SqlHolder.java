package net.fastm.sql;

public abstract interface SqlHolder
{
  public abstract SqlParam getSqlParam(Object paramObject);
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.sql.SqlHolder
 * JD-Core Version:    0.6.0
 */