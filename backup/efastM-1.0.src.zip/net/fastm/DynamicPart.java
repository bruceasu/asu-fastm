/*     */ package net.fastm;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.fastm.interceptors.NullInterceptor;
/*     */ import net.util.express.ExpressUtils;
/*     */ 
/*     */ public class DynamicPart
/*     */   implements ITemplate
/*     */ {
/*  33 */   static final Logger log = Logger.getLogger(DynamicPart.class.getName());
/*     */ 
/*  38 */   String name = null;
/*     */ 
/*  40 */   boolean goodName = false;
/*     */ 
/*  45 */   List steps = new ArrayList();
/*     */ 
/*  51 */   Object globalObj = null;
/*     */ 
/*     */   public DynamicPart(String name)
/*     */   {
/*  59 */     setName(name);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  67 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String string)
/*     */   {
/*  74 */     this.name = string;
/*  75 */     this.goodName = (this.name.indexOf(' ') < 0);
/*     */   }
/*     */ 
/*     */   public List getSteps()
/*     */   {
/*  84 */     return this.steps;
/*     */   }
/*     */ 
/*     */   public void setSteps(List steps)
/*     */   {
/*  92 */     this.steps = steps;
/*     */   }
/*     */ 
/*     */   public void addStep(ITemplate step)
/*     */   {
/* 101 */     if (this.steps == null) {
/* 102 */       this.steps = new ArrayList();
/*     */     }
/*     */ 
/* 105 */     this.steps.add(step);
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer)
/*     */   {
/* 114 */     write(obj, writer, DefaultInterceptor.instance);
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer, IValueInterceptor interceptor)
/*     */   {
/* 124 */     if (obj == null) return;
/* 125 */     boolean isIterator = false;
/*     */ 
/* 127 */     if (obj.getClass().isArray())
/*     */     {
/* 129 */       int n = Array.getLength(obj);
/* 130 */       for (int i = 0; i < n; i++) {
/* 131 */         Object o = Array.get(obj, i);
/* 132 */         stepDown(o, writer, interceptor);
/*     */       }
/* 134 */     } else if (((obj instanceof Collection)) || ((isIterator = obj instanceof Iterator))) {
/* 135 */       Iterator iterator = isIterator ? (Iterator)obj : ((Collection)obj).iterator();
/* 136 */       while (iterator.hasNext()) {
/* 137 */         Object o = iterator.next();
/* 138 */         stepDown(o, writer, interceptor);
/*     */       }
/* 140 */     } else if ((obj instanceof ResultSet)) {
/* 141 */       ResultSet rs = (ResultSet)obj;
/*     */       try {
/* 143 */         while (rs.next())
/* 144 */           stepDown(rs, writer, interceptor);
/*     */       }
/*     */       catch (Exception e) {
/* 147 */         throw new RuntimeException(e);
/*     */       }
/* 149 */     } else if ((obj instanceof ITemplate))
/*     */     {
/* 151 */       writer.write(obj.toString());
/*     */     } else {
/* 153 */       stepDown(obj, writer, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stepDown(Object obj, PrintWriter writer, IValueInterceptor interceptor)
/*     */   {
/* 163 */     if (interceptor == null) interceptor = DefaultInterceptor.instance;
/*     */ 
/* 165 */     boolean isValueSet = false;
/* 166 */     IValueSet valueSet = null;
/* 167 */     if ((obj instanceof IValueSet)) {
/* 168 */       isValueSet = true;
/* 169 */       valueSet = (IValueSet)obj;
/*     */     }
/*     */ 
/* 173 */     if ((this.steps == null) || (this.steps.isEmpty())) return;
/* 174 */     int nSteps = this.steps.size();
/*     */ 
/* 177 */     for (int i = 0; i < nSteps; i++) {
/* 178 */       ITemplate step = (ITemplate)this.steps.get(i);
/*     */ 
/* 182 */       if ((step instanceof ConditionDynamicPart)) {
/* 183 */         ConditionDynamicPart dynPart = (ConditionDynamicPart)step;
/* 184 */         String dynName = dynPart.getName();
/* 185 */         boolean conditionResult = getComplexConditionResult(dynName, obj, interceptor);
/* 186 */         if (conditionResult) {
/* 187 */           dynPart.setGlobalObj(this.globalObj);
/* 188 */           dynPart.write(obj, writer, interceptor);
/*     */         }
/* 190 */       } else if ((step instanceof DynamicPart)) {
/* 191 */         DynamicPart dynPart = (DynamicPart)step;
/* 192 */         String dynName = dynPart.getName();
/*     */ 
/* 194 */         Object branch = null;
/* 195 */         if (isValueSet) {
/* 196 */           branch = valueSet.getDynamicValueSets(dynName);
/* 197 */           if (branch == null) branch = valueSet.getVariable(dynName); 
/*     */         }
/* 198 */         else if (this.goodName) {
/* 199 */           branch = interceptor.getProperty(obj, dynName);
/*     */         }
/* 201 */         dynPart.setGlobalObj(this.globalObj);
/* 202 */         dynPart.write(branch, writer, interceptor);
/* 203 */       } else if ((step instanceof GlobalVariablePart)) {
/* 204 */         step.write(this.globalObj, writer, interceptor);
/*     */       } else {
/* 206 */         step.write(obj, writer, interceptor);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean getComplexConditionResult(String express, Object obj, IValueInterceptor interceptor)
/*     */   {
/* 225 */     String targetStr = express.trim().substring(10).trim();
/* 226 */     targetStr = targetStr.replaceAll("&&", "&");
/* 227 */     targetStr = targetStr.replaceAll("\\|\\|", "\\|");
/* 228 */     ArrayList expression = new ArrayList();
/* 229 */     StringTokenizer st = new StringTokenizer(targetStr, "()|&", true);
/* 230 */     while (st.hasMoreElements()) {
/* 231 */       expression.add(st.nextToken());
/*     */     }
/* 233 */     StringBuffer complexExpress = new StringBuffer();
/* 234 */     for (Iterator iter = expression.iterator(); iter.hasNext(); ) {
/* 235 */       String item = (String)iter.next();
/* 236 */       item = item == null ? "" : item.trim();
/* 237 */       if ("".equals(item)) {
/*     */         continue;
/*     */       }
/* 240 */       if (("(".equals(item)) || (")".equals(item)) || ("|".equals(item)) || ("&".equals(item))) {
/* 241 */         complexExpress.append(item);
/*     */       } else {
/* 243 */         boolean result = getConditionResult(item, obj, interceptor);
/* 244 */         complexExpress.append(String.valueOf(result));
/*     */       }
/*     */     }
/* 247 */     return ExpressUtils.judge(complexExpress.toString());
/*     */   }
/*     */ 
/*     */   private boolean getConditionResult(String dynName, Object obj, IValueInterceptor interceptor)
/*     */   {
/*     */     try
/*     */     {
/* 262 */       String targetStr = dynName.trim();
/*     */ 
/* 264 */       String regEx = "[\"}0123456789]\\s*(==|!=|>=|\\*|!\\*|<=|>|<)\\s*[\"{0123456789]";
/* 265 */       Pattern pattern = Pattern.compile(regEx);
/* 266 */       Matcher matcher = pattern.matcher(targetStr);
/* 267 */       matcher.find();
/*     */ 
/* 269 */       int n1 = matcher.start();
/* 270 */       int n2 = matcher.end();
/*     */ 
/* 272 */       String compare1 = targetStr.substring(0, n1 + 1).trim();
/* 273 */       String logicStr = targetStr.substring(n1 + 1, n2 - 1).trim();
/* 274 */       String compare2 = targetStr.substring(n2 - 1).trim();
/*     */ 
/* 276 */       compare1 = getCompareValue(compare1, obj, interceptor);
/* 277 */       compare2 = getCompareValue(compare2, obj, interceptor);
/*     */ 
/* 279 */       if (logicStr.equals("=="))
/*     */       {
/* 281 */         return compare1.equals(compare2);
/* 282 */       }if (logicStr.equals("!="))
/* 283 */         return !compare1.equals(compare2);
/* 284 */       if (logicStr.equals("*"))
/* 285 */         return compare1.matches(compare2);
/* 286 */       if (logicStr.equals("!*")) {
/* 287 */         return !compare1.matches(compare2);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 292 */         long compareNum1 = Long.parseLong(compare1);
/* 293 */         compareNum2 = Long.parseLong(compare2);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */         long compareNum2;
/* 296 */         System.out.print("ERROR! fail to get number:" + compare1 + "," + compare2);
/* 297 */         return false;
/*     */       }
/*     */       long compareNum2;
/*     */       long compareNum1;
/* 300 */       if (logicStr.equals(">"))
/* 301 */         return compareNum1 > compareNum2;
/* 302 */       if (logicStr.equals("<"))
/* 303 */         return compareNum1 < compareNum2;
/* 304 */       if (logicStr.equals(">="))
/* 305 */         return compareNum1 >= compareNum2;
/* 306 */       if (logicStr.equals("<=")) {
/* 307 */         return compareNum1 <= compareNum2;
/*     */       }
/* 309 */       System.out.print("ERROR! fail to parse logicStr:" + logicStr);
/* 310 */       return false;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 316 */       System.out.print("ERROR! fail to parse: method getConditionResult");
/* 317 */     }return false;
/*     */   }
/*     */ 
/*     */   private String getCompareValue(String compareStr, Object obj, IValueInterceptor interceptor)
/*     */   {
/* 333 */     compareStr = compareStr.trim();
/* 334 */     if ((compareStr.startsWith("{")) && (compareStr.endsWith("}"))) {
/* 335 */       VariablePart varPart = new VariablePart(compareStr);
/* 336 */       if (compareStr.startsWith("{global_")) {
/* 337 */         return varPart.toString(this.globalObj, interceptor);
/*     */       }
/* 339 */       return varPart.toString(obj, interceptor);
/* 340 */     }if ((compareStr.startsWith("\"")) && (compareStr.endsWith("\""))) {
/* 341 */       compareStr = compareStr.substring(1, compareStr.length() - 1);
/* 342 */       return compareStr.replaceAll("\\\\\"", "\"");
/*     */     }
/* 344 */     return compareStr;
/*     */   }
/*     */ 
/*     */   public void setGlobalObjByTop(Object obj)
/*     */   {
/* 356 */     if ((obj instanceof Map))
/*     */     {
/* 358 */       Map globalMap = new HashMap();
/* 359 */       Map map = (Map)obj;
/* 360 */       Iterator iter = map.entrySet().iterator();
/* 361 */       for (int i = 0; i < map.size(); i++)
/*     */       {
/* 363 */         Map.Entry entry = (Map.Entry)iter.next();
/* 364 */         String key = (String)entry.getKey();
/* 365 */         Object value = entry.getValue();
/* 366 */         if (!key.startsWith("global_"))
/*     */           continue;
/* 368 */         globalMap.put(key, value);
/*     */       }
/*     */ 
/* 371 */       this.globalObj = globalMap;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setGlobalObj(Object obj)
/*     */   {
/* 382 */     this.globalObj = obj;
/*     */   }
/*     */ 
/*     */   public String toString(Object obj)
/*     */   {
/* 393 */     return toString(obj, DefaultInterceptor.instance);
/*     */   }
/*     */ 
/*     */   public String toString(Object obj, IValueInterceptor interceptor)
/*     */   {
/* 414 */     setGlobalObjByTop(obj);
/*     */ 
/* 416 */     StringWriter strWriter = new StringWriter();
/* 417 */     PrintWriter printer = new PrintWriter(strWriter);
/*     */ 
/* 419 */     write(obj, printer, interceptor);
/* 420 */     return strWriter.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 427 */     if ((this.steps == null) || (this.steps.isEmpty())) return "";
/*     */ 
/* 430 */     StringBuffer buf = new StringBuffer();
/*     */ 
/* 432 */     int nSteps = this.steps.size();
/*     */ 
/* 435 */     for (int i = 0; i < nSteps; i++) {
/* 436 */       ITemplate step = (ITemplate)this.steps.get(i);
/*     */ 
/* 438 */       if ((step instanceof DynamicPart)) {
/* 439 */         DynamicPart dynPart = (DynamicPart)step;
/* 440 */         String dynName = dynPart.getName();
/* 441 */         buf.append("<!-- BEGIN DYNAMIC: " + dynName + " -->\n");
/* 442 */         buf.append(dynPart);
/* 443 */         buf.append("<!-- END DYNAMIC: " + dynName + " -->\n");
/*     */       }
/*     */       else {
/* 446 */         buf.append(step);
/*     */       }
/*     */     }
/*     */ 
/* 450 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public String structure(int level)
/*     */   {
/* 459 */     StringBuffer buf = new StringBuffer();
/*     */ 
/* 461 */     for (int i = 0; i < level; i++) buf.append(" ");
/* 462 */     buf.append("Dynamic: " + this.name + "\n");
/* 463 */     level++;
/*     */ 
/* 465 */     int nSteps = this.steps.size();
/* 466 */     for (int i = 0; i < nSteps; i++) {
/* 467 */       ITemplate step = (ITemplate)this.steps.get(i);
/*     */ 
/* 469 */       buf.append(step.structure(level));
/*     */     }
/*     */ 
/* 472 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public List getDynamicChildren()
/*     */   {
/* 480 */     int nSteps = this.steps.size();
/* 481 */     List dynChildren = new ArrayList();
/*     */ 
/* 483 */     for (int i = 0; i < nSteps; i++) {
/* 484 */       Object obj = this.steps.get(i);
/*     */ 
/* 486 */       if ((obj instanceof DynamicPart)) {
/* 487 */         dynChildren.add(obj);
/*     */       }
/*     */     }
/*     */ 
/* 491 */     return dynChildren;
/*     */   }
/*     */ 
/*     */   public List getVariables()
/*     */   {
/* 499 */     int nSteps = this.steps.size();
/* 500 */     List variables = new ArrayList();
/*     */ 
/* 502 */     for (int i = 0; i < nSteps; i++) {
/* 503 */       Object obj = this.steps.get(i);
/*     */ 
/* 505 */       if ((obj instanceof VariablePart)) {
/* 506 */         variables.add(obj);
/*     */       }
/*     */     }
/*     */ 
/* 510 */     return variables;
/*     */   }
/*     */ 
/*     */   public DynamicPart findWidthFirst(Object obj)
/*     */   {
/* 520 */     if (obj == null) return null;
/* 521 */     List dynChildren = getDynamicChildren();
/*     */ 
/* 523 */     List queue = new LinkedList();
/* 524 */     queue.addAll(dynChildren);
/*     */ 
/* 526 */     while (queue.size() > 0) {
/* 527 */       DynamicPart dynPart = (DynamicPart)queue.remove(0);
/*     */ 
/* 529 */       if (obj.equals(dynPart.getName())) {
/* 530 */         return dynPart;
/*     */       }
/*     */ 
/* 533 */       queue.addAll(dynPart.getDynamicChildren());
/*     */     }
/*     */ 
/* 537 */     return null;
/*     */   }
/*     */ 
/*     */   public DynamicPart findDepthFirst(Object obj)
/*     */   {
/* 547 */     if (obj == null) return null;
/*     */ 
/* 549 */     List dynChildren = getDynamicChildren();
/* 550 */     int nChildren = dynChildren.size();
/*     */ 
/* 552 */     for (int i = 0; i < nChildren; i++) {
/* 553 */       DynamicPart dynPart = (DynamicPart)dynChildren.get(i);
/*     */ 
/* 555 */       if (obj.equals(dynPart.getName())) {
/* 556 */         return dynPart;
/*     */       }
/*     */ 
/* 559 */       dynPart = dynPart.findDepthFirst(obj);
/*     */ 
/* 561 */       if (dynPart != null) {
/* 562 */         return dynPart;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 567 */     return null;
/*     */   }
/*     */ 
/*     */   public ITemplate replaceNode(String name, ITemplate newTemplate)
/*     */   {
/* 578 */     if ((this.steps == null) || (this.steps.isEmpty())) return null;
/* 579 */     if (this.name.compareTo(name) == 0) return newTemplate;
/* 580 */     if (findDepthFirst(name) == null) return this;
/*     */ 
/* 582 */     DynamicPart newDyn = new DynamicPart(this.name);
/*     */ 
/* 584 */     int nSteps = this.steps.size();
/* 585 */     for (int i = 0; i < nSteps; i++) {
/* 586 */       ITemplate step = (ITemplate)this.steps.get(i);
/*     */ 
/* 588 */       if ((step instanceof DynamicPart)) {
/* 589 */         DynamicPart dyn = (DynamicPart)step;
/* 590 */         step = dyn.replaceNode(name, newTemplate);
/*     */       }
/*     */ 
/* 593 */       newDyn.addStep(step);
/*     */     }
/*     */ 
/* 596 */     return newDyn;
/*     */   }
/*     */ 
/*     */   public Map getIncludes(Object model, String[] includeNames, String prefix)
/*     */   {
/* 607 */     Map includes = new HashMap();
/* 608 */     for (int i = 0; i < includeNames.length; i++) {
/* 609 */       String includeName = includeNames[i];
/* 610 */       DynamicPart part = findWidthFirst(prefix + includeName);
/* 611 */       String str = part.toString(model, new NullInterceptor());
/* 612 */       StaticPart text = new StaticPart(str);
/* 613 */       includes.put(includeName, text);
/*     */     }
/* 615 */     return includes;
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.DynamicPart
 * JD-Core Version:    0.6.0
 */