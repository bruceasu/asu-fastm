/*    */ package net.fastm;
/*    */ 
/*    */ import net.util.BeanUtils;
/*    */ 
/*    */ public class DefaultInterceptor
/*    */   implements IValueInterceptor
/*    */ {
/* 11 */   public static final IValueInterceptor instance = new DefaultInterceptor();
/*    */ 
/*    */   public Object getProperty(Object bean, String propertyName)
/*    */   {
/*  8 */     return BeanUtils.getProperty(bean, propertyName);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.DefaultInterceptor
 * JD-Core Version:    0.6.0
 */