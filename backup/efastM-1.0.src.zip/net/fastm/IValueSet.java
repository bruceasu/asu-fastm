package net.fastm;

import java.util.List;
import java.util.Map;

public abstract interface IValueSet
{
  public abstract Object getVariable(String paramString);

  public abstract void setVariable(String paramString, Object paramObject);

  public abstract List getDynamicValueSets(String paramString);

  public abstract void setDynamicValueSets(String paramString, List paramList);

  public abstract void addDynamicValueSet(String paramString, IValueSet paramIValueSet);

  public abstract void setDynamicValueSet(String paramString, IValueSet paramIValueSet);

  public abstract Map getVariableMap();

  public abstract Map getDynamicMap();
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.IValueSet
 * JD-Core Version:    0.6.0
 */