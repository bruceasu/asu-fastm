/*    */ package net.fastm;
/*    */ 
/*    */ public class GlobalVariablePart extends VariablePart
/*    */ {
/*    */   public GlobalVariablePart(String name)
/*    */   {
/* 13 */     super(name);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.GlobalVariablePart
 * JD-Core Version:    0.6.0
 */