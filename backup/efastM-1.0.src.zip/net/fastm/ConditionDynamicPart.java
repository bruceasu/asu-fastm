/*    */ package net.fastm;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class ConditionDynamicPart extends DynamicPart
/*    */ {
/*    */   public ConditionDynamicPart(String name)
/*    */   {
/* 14 */     super(name);
/*    */   }
/*    */ 
/*    */   public void write(Object obj, PrintWriter writer, IValueInterceptor interceptor)
/*    */   {
/* 26 */     DynamicPart dPart = new DynamicPart("temp" + 
/* 27 */       new Random(System.currentTimeMillis()).nextInt());
/*    */ 
/* 29 */     dPart.setSteps(getSteps());
/* 30 */     dPart.setGlobalObj(this.globalObj);
/*    */ 
/* 32 */     dPart.write(obj, writer, interceptor);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.ConditionDynamicPart
 * JD-Core Version:    0.6.0
 */