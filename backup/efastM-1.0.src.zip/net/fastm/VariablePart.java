/*     */ package net.fastm;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ public class VariablePart
/*     */   implements ITemplate
/*     */ {
/*  17 */   String name = null;
/*  18 */   String propName = null;
/*  19 */   boolean goodName = false;
/*     */ 
/*     */   public VariablePart(String name)
/*     */   {
/*  23 */     setName(name);
/*     */   }
/*     */ 
/*     */   public String getPropName()
/*     */   {
/*  31 */     return this.propName;
/*     */   }
/*     */ 
/*     */   public void setName(String string)
/*     */   {
/*  38 */     this.name = string;
/*  39 */     this.propName = this.name.substring(1, this.name.length() - 1);
/*  40 */     this.goodName = (this.propName.indexOf(' ') < 0);
/*     */   }
/*     */ 
/*     */   public void setPropName(String string) {
/*  44 */     this.propName = string;
/*  45 */     this.goodName = (this.propName.indexOf(' ') < 0);
/*  46 */     this.name = ("{" + this.propName + "}");
/*     */   }
/*     */ 
/*     */   public String toString(Object obj)
/*     */   {
/*  55 */     return toString(obj, DefaultInterceptor.instance);
/*     */   }
/*     */ 
/*     */   public String toString(Object obj, IValueInterceptor valueInterceptor)
/*     */   {
/*  65 */     if (valueInterceptor == null) valueInterceptor = DefaultInterceptor.instance;
/*     */ 
/*  67 */     if (obj == null) return this.name;
/*  68 */     if ((obj instanceof Object[])) {
/*  69 */       Object[] a = (Object[])obj;
/*  70 */       if (a.length > 0) obj = a[0];
/*     */     }
/*     */ 
/*  73 */     boolean isValueSet = obj instanceof IValueSet;
/*     */ 
/*  75 */     Object value = null;
/*  76 */     if (isValueSet)
/*  77 */       value = ((IValueSet)obj).getVariable(this.name);
/*  78 */     else if (this.goodName) {
/*  79 */       value = valueInterceptor.getProperty(obj, this.propName);
/*     */     }
/*     */ 
/*  82 */     if (value == null) return this.name;
/*     */ 
/*  84 */     return value.toString();
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer)
/*     */   {
/*  93 */     write(obj, writer, DefaultInterceptor.instance);
/*     */   }
/*     */ 
/*     */   public void write(Object obj, PrintWriter writer, IValueInterceptor valueInterceptor) {
/*  97 */     writer.write(toString(obj, valueInterceptor));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 103 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String structure(int level)
/*     */   {
/* 109 */     StringBuffer buf = new StringBuffer();
/*     */ 
/* 111 */     for (int i = 0; i < level; i++) buf.append(" ");
/* 112 */     buf.append("Variable: " + this.name + "\n");
/*     */ 
/* 114 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.VariablePart
 * JD-Core Version:    0.6.0
 */