package net.fastm;

import java.io.PrintWriter;

public abstract interface ITemplate
{
  public abstract String toString(Object paramObject);

  public abstract String toString(Object paramObject, IValueInterceptor paramIValueInterceptor);

  public abstract void write(Object paramObject, PrintWriter paramPrintWriter);

  public abstract void write(Object paramObject, PrintWriter paramPrintWriter, IValueInterceptor paramIValueInterceptor);

  public abstract String structure(int paramInt);
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.ITemplate
 * JD-Core Version:    0.6.0
 */