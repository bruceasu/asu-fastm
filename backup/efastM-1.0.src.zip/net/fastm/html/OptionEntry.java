/*    */ package net.fastm.html;
/*    */ 
/*    */ public class OptionEntry extends Entry
/*    */   implements IOptionEntry
/*    */ {
/*    */   private IOptionInfo optionInfo;
/*    */ 
/*    */   public OptionEntry()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OptionEntry(String propertyName, OptionInfo optionInfo)
/*    */   {
/*  8 */     setPropertyName(propertyName);
/*  9 */     setOptionInfo(optionInfo);
/*    */   }
/*    */ 
/*    */   public IOptionInfo getOptionInfo() {
/* 13 */     return this.optionInfo;
/*    */   }
/*    */   public void setOptionInfo(IOptionInfo optionInfo) {
/* 16 */     this.optionInfo = optionInfo;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.OptionEntry
 * JD-Core Version:    0.6.0
 */