package net.fastm.html;

public abstract interface IOptionEntry extends IEntry
{
  public abstract IOptionInfo getOptionInfo();
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.IOptionEntry
 * JD-Core Version:    0.6.0
 */