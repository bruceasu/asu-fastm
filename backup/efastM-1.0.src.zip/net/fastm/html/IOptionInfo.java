package net.fastm.html;

public abstract interface IOptionInfo
{
  public abstract Object[] getValues();

  public abstract Object[] getDisplays();

  public abstract String getValueName();

  public abstract String getDisplayName();
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.IOptionInfo
 * JD-Core Version:    0.6.0
 */