/*    */ package net.fastm.html;
/*    */ 
/*    */ public class RadioEntry extends Entry
/*    */   implements IRadioEntry
/*    */ {
/*    */   private Object[] values;
/*    */ 
/*    */   public RadioEntry()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RadioEntry(String propertyName, Object[] values)
/*    */   {
/*  8 */     setPropertyName(propertyName);
/*  9 */     setValues(values);
/*    */   }
/*    */ 
/*    */   public Object[] getValues() {
/* 13 */     return this.values;
/*    */   }
/*    */   public void setValues(Object[] values) {
/* 16 */     this.values = values;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.RadioEntry
 * JD-Core Version:    0.6.0
 */