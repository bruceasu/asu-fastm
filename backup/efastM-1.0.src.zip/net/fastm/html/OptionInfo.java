/*    */ package net.fastm.html;
/*    */ 
/*    */ public class OptionInfo
/*    */   implements IOptionInfo
/*    */ {
/*    */   private Object[] values;
/*    */   private Object[] displays;
/*  6 */   private String valueName = "value";
/*  7 */   private String displayName = "display";
/*    */ 
/*    */   public OptionInfo() {
/*    */   }
/* 11 */   public OptionInfo(Object[] values) { setValues(values); }
/*    */ 
/*    */   public OptionInfo(Object[] values, Object[] displays) {
/* 14 */     setValues(values);
/* 15 */     setDisplays(displays);
/*    */   }
/*    */ 
/*    */   public String getDisplayName() {
/* 19 */     return this.displayName;
/*    */   }
/*    */   public void setDisplayName(String displayName) {
/* 22 */     this.displayName = displayName;
/*    */   }
/*    */   public Object[] getDisplays() {
/* 25 */     if (this.displays == null) return this.values;
/* 26 */     return this.displays;
/*    */   }
/*    */   public void setDisplays(Object[] displays) {
/* 29 */     this.displays = displays;
/*    */   }
/*    */   public String getValueName() {
/* 32 */     return this.valueName;
/*    */   }
/*    */   public void setValueName(String valueName) {
/* 35 */     this.valueName = valueName;
/*    */   }
/*    */   public Object[] getValues() {
/* 38 */     return this.values;
/*    */   }
/*    */   public void setValues(Object[] values) {
/* 41 */     this.values = values;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.OptionInfo
 * JD-Core Version:    0.6.0
 */