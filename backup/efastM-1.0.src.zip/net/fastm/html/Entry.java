/*   */ package net.fastm.html;
/*   */ 
/*   */ public class Entry
/*   */   implements IEntry
/*   */ {
/*   */   private String propertyName;
/*   */ 
/*   */   public String getPropertyName()
/*   */   {
/* 6 */     return this.propertyName;
/*   */   }
/*   */   public void setPropertyName(String propertyName) {
/* 9 */     this.propertyName = propertyName;
/*   */   }
/*   */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.Entry
 * JD-Core Version:    0.6.0
 */