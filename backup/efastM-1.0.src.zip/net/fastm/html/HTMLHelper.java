/*     */ package net.fastm.html;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.util.BeanUtils;
/*     */ 
/*     */ public class HTMLHelper
/*     */ {
/*     */   public static List buildOptions(Object value, IOptionInfo optionInfo)
/*     */   {
/*  18 */     Object[] values = optionInfo.getValues();
/*  19 */     if (values == null) return null;
/*     */ 
/*  21 */     Object[] displays = optionInfo.getDisplays();
/*     */ 
/*  23 */     int n = values.length;
/*  24 */     String valueName = optionInfo.getValueName();
/*  25 */     String displayName = optionInfo.getDisplayName();
/*  26 */     List list = new ArrayList(n);
/*     */ 
/*  28 */     for (int i = 0; i < n; i++) {
/*  29 */       Object option = values[i];
/*  30 */       Object display = displays[i];
/*     */ 
/*  32 */       Map map = new HashMap();
/*  33 */       map.put(valueName, option);
/*  34 */       map.put(displayName, display);
/*  35 */       String selected = option.equals(value) ? "selected" : "";
/*  36 */       map.put("selected", selected);
/*  37 */       list.add(map);
/*     */     }
/*     */ 
/*  40 */     return list;
/*     */   }
/*     */ 
/*     */   public static Map buildRadios(Object value, Object[] data)
/*     */   {
/*  50 */     Map map = buildEmptyRadios(data);
/*  51 */     if (value != null) map.put(value, "checked");
/*  52 */     return map;
/*     */   }
/*     */ 
/*     */   public static Map buildEmptyRadios(Object[] data)
/*     */   {
/*  61 */     Map map = new HashMap();
/*  62 */     for (int i = 0; i < data.length; i++) {
/*  63 */       map.put(data[i], "");
/*     */     }
/*  65 */     return map;
/*     */   }
/*     */ 
/*     */   public static Map mapOptions(Object bean, IOptionEntry[] data)
/*     */   {
/*  77 */     Map map = new HashMap();
/*  78 */     for (int i = 0; i < data.length; i++) {
/*  79 */       IOptionEntry entry = data[i];
/*  80 */       String propertyName = entry.getPropertyName();
/*  81 */       IOptionInfo optionInfo = entry.getOptionInfo();
/*     */ 
/*  83 */       Object value = BeanUtils.getProperty(bean, propertyName);
/*  84 */       List options = buildOptions(value, optionInfo);
/*     */ 
/*  86 */       map.put(propertyName, options);
/*     */     }
/*  88 */     return map;
/*     */   }
/*     */ 
/*     */   public static Map mapRadios(Object bean, IRadioEntry[] data)
/*     */   {
/*  97 */     Map map = new HashMap();
/*  98 */     for (int i = 0; i < data.length; i++) {
/*  99 */       IRadioEntry entry = data[i];
/* 100 */       String propertyName = entry.getPropertyName();
/* 101 */       Object[] values = entry.getValues();
/*     */ 
/* 103 */       Object value = BeanUtils.getProperty(bean, propertyName);
/* 104 */       Map radios = buildRadios(value, values);
/*     */ 
/* 106 */       map.put(propertyName, radios);
/*     */     }
/* 108 */     return map;
/*     */   }
/*     */ 
/*     */   public static Map mapOptionsRadios(Object bean, IOptionEntry[] optionsData, IRadioEntry[] radiosData)
/*     */   {
/* 121 */     Map optionsMap = mapOptions(bean, optionsData);
/* 122 */     Map radiosMap = mapRadios(bean, radiosData);
/*     */ 
/* 124 */     Map map = new HashMap();
/* 125 */     map.put("option", optionsMap);
/* 126 */     map.put("radio", radiosMap);
/* 127 */     return map;
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.HTMLHelper
 * JD-Core Version:    0.6.0
 */