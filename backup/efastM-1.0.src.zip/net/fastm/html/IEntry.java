package net.fastm.html;

public abstract interface IEntry
{
  public abstract String getPropertyName();
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.html.IEntry
 * JD-Core Version:    0.6.0
 */