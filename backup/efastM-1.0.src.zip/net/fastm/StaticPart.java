/*    */ package net.fastm;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class StaticPart
/*    */   implements ITemplate
/*    */ {
/* 16 */   String str = null;
/*    */ 
/*    */   public StaticPart(String str) {
/* 19 */     this.str = str;
/*    */   }
/*    */ 
/*    */   public String toString(Object obj)
/*    */   {
/* 27 */     return this.str;
/*    */   }
/*    */ 
/*    */   public String toString(Object obj, IValueInterceptor valueInterceptor)
/*    */   {
/* 37 */     return this.str;
/*    */   }
/*    */ 
/*    */   public void write(Object obj, PrintWriter writer)
/*    */   {
/* 46 */     if (obj == null) return;
/* 47 */     writer.write(this.str);
/*    */   }
/*    */ 
/*    */   public void write(Object obj, PrintWriter writer, IValueInterceptor valueInterceptor)
/*    */   {
/* 57 */     write(obj, writer);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 64 */     return this.str;
/*    */   }
/*    */ 
/*    */   public String structure(int level)
/*    */   {
/* 71 */     StringBuffer buf = new StringBuffer();
/*    */ 
/* 73 */     for (int i = 0; i < level; i++) buf.append(" ");
/* 74 */     buf.append("Static \n");
/*    */ 
/* 76 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.fastm.StaticPart
 * JD-Core Version:    0.6.0
 */