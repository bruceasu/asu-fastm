/*    */ package net.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ReadWriteMap
/*    */   implements Map
/*    */ {
/* 17 */   protected volatile Map mapToRead = getNewMap();
/*    */ 
/*    */   protected Map getNewMap()
/*    */   {
/* 21 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   protected Map copy()
/*    */   {
/* 26 */     Map newMap = getNewMap();
/* 27 */     newMap.putAll(this.mapToRead);
/* 28 */     return newMap;
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 33 */     return this.mapToRead.size();
/*    */   }
/*    */   public boolean isEmpty() {
/* 36 */     return this.mapToRead.isEmpty();
/*    */   }
/*    */ 
/*    */   public boolean containsKey(Object key) {
/* 40 */     return this.mapToRead.containsKey(key);
/*    */   }
/*    */ 
/*    */   public boolean containsValue(Object value) {
/* 44 */     return this.mapToRead.containsValue(value);
/*    */   }
/*    */ 
/*    */   public Collection values() {
/* 48 */     return this.mapToRead.values();
/*    */   }
/*    */ 
/*    */   public Set entrySet() {
/* 52 */     return this.mapToRead.entrySet();
/*    */   }
/*    */ 
/*    */   public Set keySet() {
/* 56 */     return this.mapToRead.keySet();
/*    */   }
/*    */ 
/*    */   public Object get(Object key) {
/* 60 */     return this.mapToRead.get(key);
/*    */   }
/*    */ 
/*    */   public synchronized void clear()
/*    */   {
/* 65 */     this.mapToRead = getNewMap();
/*    */   }
/*    */ 
/*    */   public synchronized Object remove(Object key) {
/* 69 */     Map map = copy();
/* 70 */     Object o = map.remove(key);
/* 71 */     this.mapToRead = map;
/* 72 */     return o;
/*    */   }
/*    */ 
/*    */   public synchronized Object put(Object key, Object value) {
/* 76 */     Map map = copy();
/* 77 */     Object o = map.put(key, value);
/* 78 */     this.mapToRead = map;
/* 79 */     return o;
/*    */   }
/*    */ 
/*    */   public synchronized void putAll(Map t) {
/* 83 */     Map map = copy();
/* 84 */     map.putAll(t);
/* 85 */     this.mapToRead = map;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.ReadWriteMap
 * JD-Core Version:    0.6.0
 */