package net.util.express;

public abstract interface ComputeITF
{
  public abstract Double compute(String paramString);

  public abstract boolean judge(String paramString);
}

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.express.ComputeITF
 * JD-Core Version:    0.6.0
 */