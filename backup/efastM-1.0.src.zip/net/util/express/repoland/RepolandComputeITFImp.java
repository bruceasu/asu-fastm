/*     */ package net.util.express.repoland;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import net.util.express.ComputeITF;
/*     */ 
/*     */ public class RepolandComputeITFImp
/*     */   implements ComputeITF
/*     */ {
/*  17 */   private ArrayList expression = new ArrayList();
/*     */ 
/*  20 */   private ArrayList right = new ArrayList();
/*     */ 
/*  23 */   private Object valueSet = null;
/*     */ 
/*     */   public Double compute(String express) {
/*  26 */     StringTokenizer st = new StringTokenizer(express, "+-*/()", true);
/*  27 */     while (st.hasMoreElements()) {
/*  28 */       this.expression.add(st.nextToken());
/*     */     }
/*  30 */     return Double.valueOf(getResult());
/*     */   }
/*     */ 
/*     */   public boolean judge(String express) {
/*  34 */     StringTokenizer st = new StringTokenizer(express, "+-*/()!|=&", true);
/*  35 */     while (st.hasMoreElements()) {
/*  36 */       this.expression.add(st.nextToken());
/*     */     }
/*  38 */     return Boolean.valueOf(getResult()).booleanValue();
/*     */   }
/*     */ 
/*     */   private void toRight()
/*     */   {
/*  45 */     FastmStack aStack = new FastmStack();
/*  46 */     String operator = null;
/*  47 */     int position = 0;
/*     */     while (true) {
/*  49 */       if (Calculate.isOperator((String)this.expression.get(position))) {
/*  50 */         if ((aStack.isEmpty()) || (((String)this.expression.get(position)).equals("("))) {
/*  51 */           aStack.push(this.expression.get(position));
/*     */         }
/*  54 */         else if (((String)this.expression.get(position)).equals(")")) {
/*  55 */           if (!((String)aStack.top()).equals("(")) {
/*  56 */             operator = (String)aStack.pop();
/*  57 */             this.right.add(operator);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  62 */           if ((Calculate.priority((String)this.expression.get(position)) <= 
/*  62 */             Calculate.priority((String)aStack.top())) && 
/*  63 */             (!aStack.isEmpty())) {
/*  64 */             operator = (String)aStack.pop();
/*  65 */             if (!operator.equals("("))
/*  66 */               this.right.add(operator);
/*     */           }
/*  68 */           aStack.push(this.expression.get(position));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  73 */         this.right.add(this.expression.get(position));
/*  74 */       }position++;
/*  75 */       if (position >= this.expression.size())
/*  76 */         break;
/*     */     }
/*  78 */     while (!aStack.isEmpty()) {
/*  79 */       operator = (String)aStack.pop();
/*  80 */       this.right.add(operator);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getResult()
/*     */   {
/*  86 */     toRight();
/*  87 */     FastmStack aStack = new FastmStack();
/*  88 */     String is = null;
/*  89 */     Iterator it = this.right.iterator();
/*     */ 
/*  91 */     while (it.hasNext()) {
/*  92 */       is = (String)it.next();
/*  93 */       if (Calculate.isOperator(is)) {
/*  94 */         int num = Calculate.operatorNum(is);
/*  95 */         if (num == 1) {
/*  96 */           String op1 = (String)aStack.pop();
/*  97 */           aStack.push(Calculate.singleOp(op1));
/*     */         }
/*  99 */         else if (num == 2) {
/* 100 */           String op1 = (String)aStack.pop();
/* 101 */           String op2 = (String)aStack.pop();
/* 102 */           aStack.push(Calculate.twoResult(is, op1, op2));
/*     */         }
/*     */       }
/*     */       else {
/* 106 */         aStack.push(is);
/*     */       }
/*     */     }
/* 109 */     return (String)aStack.pop();
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.express.repoland.RepolandComputeITFImp
 * JD-Core Version:    0.6.0
 */