/*    */ package net.util.express.repoland;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class FastmStack
/*    */ {
/* 14 */   private LinkedList list = new LinkedList();
/*    */ 
/* 16 */   private int top = -1;
/*    */ 
/*    */   public void push(Object value) {
/* 19 */     this.top += 1;
/* 20 */     this.list.addFirst(value);
/*    */   }
/*    */ 
/*    */   public Object pop() {
/* 24 */     if (this.top == -1) {
/* 25 */       return null;
/*    */     }
/* 27 */     Object temp = this.list.getFirst();
/* 28 */     this.top -= 1;
/* 29 */     this.list.removeFirst();
/* 30 */     return temp;
/*    */   }
/*    */ 
/*    */   public Object top()
/*    */   {
/* 35 */     if (this.top == -1) {
/* 36 */       return null;
/*    */     }
/* 38 */     return this.list.getFirst();
/*    */   }
/*    */ 
/*    */   public List getAllStackObjects() {
/* 42 */     List asos = new ArrayList();
/* 43 */     asos.addAll(this.list);
/* 44 */     return asos;
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 48 */     return this.list.isEmpty();
/*    */   }
/*    */ 
/*    */   public int size() {
/* 52 */     return this.list.size();
/*    */   }
/*    */ 
/*    */   public void reserse() {
/* 56 */     Object[] os = this.list.toArray();
/* 57 */     while (!isEmpty()) {
/* 58 */       pop();
/*    */     }
/* 60 */     for (int index = 0; index < os.length; index++)
/* 61 */       push(os[index]);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.express.repoland.FastmStack
 * JD-Core Version:    0.6.0
 */