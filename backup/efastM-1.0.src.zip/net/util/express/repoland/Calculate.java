/*     */ package net.util.express.repoland;
/*     */ 
/*     */ public class Calculate
/*     */ {
/*     */   public static boolean isOperator(String operator)
/*     */   {
/*  22 */     return ("+".equals(operator)) || ("-".equals(operator)) || ("*".equals(operator)) || 
/*  19 */       ("/".equals(operator)) || ("(".equals(operator)) || (")".equals(operator)) || 
/*  20 */       ("|".equals(operator)) || ("&".equals(operator)) || ("!".equals(operator)) || 
/*  21 */       ("=".equals(operator));
/*     */   }
/*     */ 
/*     */   public static int operatorNum(String operator)
/*     */   {
/*  36 */     if ("!".equals(operator)) {
/*  37 */       return 1;
/*     */     }
/*  39 */     return 2;
/*     */   }
/*     */ 
/*     */   public static int priority(String operator)
/*     */   {
/*  49 */     if ("|".equals(operator)) {
/*  50 */       return 1;
/*     */     }
/*  52 */     if ("&".equals(operator)) {
/*  53 */       return 2;
/*     */     }
/*  55 */     if ("=".equals(operator)) {
/*  56 */       return 3;
/*     */     }
/*  58 */     if ("!".equals(operator)) {
/*  59 */       return 4;
/*     */     }
/*  61 */     if ((operator.equals("+")) || (operator.equals("-"))) {
/*  62 */       return 5;
/*     */     }
/*  64 */     if ((operator.equals("*")) || (operator.equals("/"))) {
/*  65 */       return 6;
/*     */     }
/*  67 */     if ((operator.equals("(")) || (operator.equals(")"))) {
/*  68 */       return 7;
/*     */     }
/*     */ 
/*  71 */     return 0;
/*     */   }
/*     */ 
/*     */   public static String twoResult(String operator, String a, String b)
/*     */   {
/*     */     try
/*     */     {
/*  88 */       String op = operator;
/*  89 */       String rs = new String();
/*  90 */       if ("=".equals(operator)) {
/*  91 */         return String.valueOf(String.valueOf(a).equals(String.valueOf(b)));
/*     */       }
/*  93 */       if ("&".equals(operator)) {
/*  94 */         return String.valueOf((Boolean.valueOf(a).booleanValue()) && 
/*  95 */           (Boolean.valueOf(b).booleanValue()));
/*     */       }
/*  97 */       if ("|".equals(operator)) {
/*  98 */         return String.valueOf((Boolean.valueOf(a).booleanValue()) || 
/*  99 */           (Boolean.valueOf(b).booleanValue()));
/*     */       }
/* 101 */       double x = Double.parseDouble(b);
/* 102 */       double y = Double.parseDouble(a);
/* 103 */       double z = 0.0D;
/* 104 */       if (op.equals("+"))
/* 105 */         z = x + y;
/* 106 */       else if (op.equals("-"))
/* 107 */         z = x - y;
/* 108 */       else if (op.equals("*"))
/* 109 */         z = x * y;
/* 110 */       else if (op.equals("/"))
/* 111 */         z = x / y;
/*     */       else
/* 113 */         z = 0.0D;
/* 114 */       return rs + z;
/*     */     } catch (NumberFormatException e) {
/*     */     }
/* 117 */     throw new RuntimeException(e.getMessage());
/*     */   }
/*     */ 
/*     */   public static String singleOp(String op)
/*     */   {
/* 128 */     boolean opValue = Boolean.valueOf(op).booleanValue();
/* 129 */     opValue = !opValue;
/* 130 */     return String.valueOf(opValue);
/*     */   }
/*     */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.express.repoland.Calculate
 * JD-Core Version:    0.6.0
 */