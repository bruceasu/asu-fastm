/*    */ package net.util.express;
/*    */ 
/*    */ import net.util.express.repoland.RepolandComputeITFImp;
/*    */ 
/*    */ public class ExpressUtils
/*    */ {
/*    */   public static boolean judge(String express)
/*    */   {
/* 23 */     ComputeITF computeITF = new RepolandComputeITFImp();
/* 24 */     return computeITF.judge(express);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.express.ExpressUtils
 * JD-Core Version:    0.6.0
 */