/*    */ package net.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class PropertyGetter
/*    */ {
/* 13 */   Method method = null;
/* 14 */   Field field = null;
/*    */ 
/*    */   public void setField(Field field)
/*    */   {
/* 20 */     this.field = field;
/*    */   }
/*    */ 
/*    */   public void setMethod(Method method)
/*    */   {
/* 27 */     this.method = method;
/*    */   }
/*    */ 
/*    */   public Object get(Object bean)
/*    */   {
/*    */     try
/*    */     {
/* 37 */       if (this.method != null) {
/* 38 */         Object[] values = (Object[])null;
/* 39 */         return this.method.invoke(bean, values);
/*    */       }
/* 41 */       if (this.field != null) return this.field.get(bean); 
/*    */     }
/*    */     catch (Exception e) {
/* 43 */       throw new RuntimeException(e);
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.PropertyGetter
 * JD-Core Version:    0.6.0
 */