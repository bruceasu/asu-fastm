/*    */ package net.util;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.sql.ResultSet;
/*    */ import java.util.Map;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class BeanUtils
/*    */ {
/* 17 */   static final Logger log = Logger.getLogger(BeanUtils.class.getName());
/* 18 */   static final Map beanMap = new ReadWriteMap();
/*    */ 
/*    */   public static Object getProperty(Object bean, String propertyName)
/*    */   {
/* 28 */     if ((bean == null) || (propertyName == null)) return null;
/*    */ 
/* 31 */     boolean isMap = bean instanceof Map;
/* 32 */     if (isMap)
/*    */     {
/* 34 */       Object value = ((Map)bean).get(propertyName);
/* 35 */       if (value != null) return value;
/*    */ 
/*    */     }
/*    */ 
/* 39 */     int dot = propertyName.indexOf('.');
/* 40 */     if (dot >= 0) {
/* 41 */       String beanName = propertyName.substring(0, dot);
/* 42 */       if (beanName.length() > 0) {
/* 43 */         bean = getProperty(bean, beanName);
/* 44 */         if (bean == null) return null;
/*    */       }
/* 46 */       propertyName = propertyName.substring(dot + 1, propertyName.length());
/* 47 */       return getProperty(bean, propertyName);
/* 48 */     }if ((bean instanceof ResultSet)) {
/* 49 */       ResultSet rs = (ResultSet)bean;
/*    */       try {
/* 51 */         return rs.getObject(propertyName);
/*    */       } catch (Exception e) {
/* 53 */         throw new RuntimeException(e);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 58 */     int leftBracket = propertyName.lastIndexOf("[");
/* 59 */     if (leftBracket >= 0) {
/* 60 */       int rightBracket = propertyName.indexOf("]", leftBracket);
/* 61 */       String preName = propertyName.substring(0, leftBracket);
/*    */ 
/* 63 */       Object value = getProperty(bean, preName);
/* 64 */       if (rightBracket > 0) {
/* 65 */         String str = propertyName.substring(leftBracket + 1, rightBracket);
/* 66 */         int index = Integer.parseInt(str);
/*    */ 
/* 68 */         if (value.getClass().isArray()) {
/* 69 */           value = Array.get(value, index);
/* 70 */         } else if ((value instanceof ResultSet)) {
/* 71 */           ResultSet rs = (ResultSet)value;
/*    */           try {
/* 73 */             value = rs.getObject(index);
/*    */           } catch (Exception e) {
/* 75 */             throw new RuntimeException(e);
/*    */           }
/*    */         }
/*    */       }
/* 79 */       return value;
/*    */     }
/*    */ 
/* 83 */     if (isMap) return null;
/*    */ 
/* 86 */     Class clazz = bean.getClass();
/* 87 */     String className = clazz.getName();
/* 88 */     BeanGetter beanGetter = (BeanGetter)beanMap.get(className);
/* 89 */     if (beanGetter == null) {
/* 90 */       beanGetter = new BeanGetter();
/* 91 */       beanGetter.setBeanClass(clazz);
/* 92 */       beanMap.put(className, beanGetter);
/*    */     }
/*    */ 
/* 95 */     Object propertyValue = beanGetter.get(bean, propertyName);
/* 96 */     if ((propertyValue == null) && ("current".equalsIgnoreCase(propertyName))) {
/* 97 */       return bean;
/*    */     }
/* 99 */     return propertyValue;
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.BeanUtils
 * JD-Core Version:    0.6.0
 */