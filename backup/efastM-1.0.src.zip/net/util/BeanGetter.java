/*    */ package net.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class BeanGetter
/*    */ {
/* 16 */   final Map propertyMap = new ReadWriteMap();
/* 17 */   Class beanClass = null;
/*    */ 
/*    */   public void setBeanClass(Class beanClass)
/*    */   {
/* 24 */     this.beanClass = beanClass;
/*    */   }
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 32 */     return this.beanClass;
/*    */   }
/*    */ 
/*    */   public Object get(Object bean, String propertyName)
/*    */   {
/* 42 */     if ((bean == null) || (propertyName == null)) return null;
/* 43 */     PropertyGetter propGetter = (PropertyGetter)this.propertyMap.get(propertyName);
/*    */ 
/* 45 */     if (propGetter == null) {
/* 46 */       boolean hit = false;
/* 47 */       Object propertyValue = null;
/*    */ 
/* 50 */       String propName = Character.toUpperCase(propertyName.charAt(0)) + 
/* 51 */         propertyName.substring(1);
/* 52 */       String methodName = "get" + propName;
/*    */ 
/* 54 */       Method method = null;
/*    */       try {
/* 56 */         Class[] args = (Class[])null;
/* 57 */         method = this.beanClass.getMethod(methodName, args);
/* 58 */         Object[] params = (Object[])null;
/* 59 */         propertyValue = method.invoke(bean, params);
/* 60 */         hit = true;
/*    */       } catch (Exception e) {
/* 62 */         method = null;
/*    */       }
/*    */ 
/* 65 */       if (!hit) {
/*    */         try {
/* 67 */           methodName = "is" + propName;
/* 68 */           Class[] args = (Class[])null;
/* 69 */           method = this.beanClass.getMethod(methodName, args);
/* 70 */           Object[] values = (Object[])null;
/* 71 */           propertyValue = method.invoke(bean, values);
/* 72 */           hit = true;
/*    */         } catch (Exception e) {
/* 74 */           method = null;
/*    */         }
/*    */       }
/*    */ 
/* 78 */       Field field = null;
/* 79 */       if (!hit) {
/*    */         try
/*    */         {
/* 82 */           field = this.beanClass.getField(propertyName);
/* 83 */           propertyValue = field.get(bean);
/* 84 */           hit = true;
/*    */         } catch (Exception e) {
/* 86 */           field = null;
/*    */         }
/*    */       }
/*    */ 
/* 90 */       propGetter = new PropertyGetter();
/* 91 */       propGetter.setMethod(method);
/* 92 */       propGetter.setField(field);
/*    */ 
/* 94 */       this.propertyMap.put(propertyName, propGetter);
/*    */ 
/* 96 */       return propertyValue;
/*    */     }
/* 98 */     return propGetter.get(bean);
/*    */   }
/*    */ }

/* Location:           /home/suk/workspace/phrase/WebContent/WEB-INF/lib/efastM-1.0.jar
 * Qualified Name:     net.util.BeanGetter
 * JD-Core Version:    0.6.0
 */