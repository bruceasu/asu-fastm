System Requirement: JDK 1.4 & above. 
No 3rd part lib needed.
The src dir contains the source file of fastm.
The test.src dir contains the test program for fastm.

Steps:
(1)include src & test.src as your source path.
(2)compile the source files.
(3)be sure that the work path as this dir.
(4)run the fastmtest.TestMain class.
   fastmtest.TestMain will parse the testTemplate.html,
   and generate the result1.html.

(5)template.jsp is just a demo to show how jsp generate the result1.html.

