package fastmtest;

import java.util.*;
import net.sf.fastm.*;
import java.io.*;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

class TestMain {
    /**
     * set the parameter tree
     *
     * @return IValueSet
     */
    public static IValueSet makeValueSet(){
        IValueSet topValueSet = new ValueSet(); // the whole document

        topValueSet.setVariable("{THE_TITLE}", "fastm test");
        topValueSet.setVariable("{A_MESSAGE}", "Hello, world");

        // set mySimpleRow
        List simpleRows = new ArrayList();
        for(int i = 0; i < 6; i++){
            IValueSet simpleRow = new ValueSet();
            simpleRow.setVariable("{COL1}", "row_" + (i+1) + ", col_1");
            simpleRow.setVariable("{COL2}", "row_" + (i+1) + ", col_2");

            simpleRows.add(simpleRow);
        }

        topValueSet.setDynamicValueSets("mySimpleRow", simpleRows);

        // An image list
        List pictures = new ArrayList();
        for (int px = 0; px < 3; px++) {
            IValueSet picture = new ValueSet();
            picture.setVariable("{PICTURE}", "images/duke" + px + ".gif");
            pictures.add(picture);
        }

        topValueSet.setDynamicValueSets("somePictures", pictures);

        // set myBigRow
        List myBigRows = new ArrayList();
        for (int row = 0; row < 5; row++) {
            // set colX
            List colXs = new ArrayList();
            for (int col = 0; col < 3; col++) {
                IValueSet colX = new ValueSet();
                colX.setVariable("{VALUE_X}", "line_" + row + ",col_" + col);
                colXs.add(colX);
            }

            // set colY
            List colYs = new ArrayList();
            for (int col = 3; col < 5; col++) {
                IValueSet colY = new ValueSet();
                colY.setVariable("{VALUE_Y}", "line_" + row + ",col(BIS)_" + col);
                colYs.add(colY);
            }

            IValueSet myBigRow = new ValueSet();
            myBigRow.setDynamicValueSets("colX", colXs);
            myBigRow.setDynamicValueSets("colY", colYs);
            myBigRows.add(myBigRow);
        }

        topValueSet.setDynamicValueSets("myBigRow", myBigRows);

        return topValueSet;
    }

    /**
     *
     * @param args String[]
     * @throws Exception
     */
    public static void main(String[] args) throws Exception{
        // TemplateLoader only load the template once.
        TemplateLoader loader = new TemplateLoader("testTemplate.html");
        // each time a template is required,
        // template loader will check the file timestamp to make sure to show the updated page.
        ITemplate template = loader.getTemplate();

		template = loader.getTemplate();
		
        FileWriter fw = new FileWriter("result1.html");
        IValueSet valueSet = makeValueSet(); // get value set
        String result = template.toString(valueSet); // assign the value set to the template
        fw.write(result);
        fw.close();
    }
}
