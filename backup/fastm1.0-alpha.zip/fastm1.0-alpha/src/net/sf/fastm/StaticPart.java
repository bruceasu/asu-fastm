package net.sf.fastm;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class StaticPart extends BaseTemplate {
    String str = null;

    public StaticPart(String str) {
        this.str = str;
    }

    public String toString(IValueSet valueSet) {
        return str;
    }

    public String structure(int level){
        return printSpace(level) + "Static \n";
    }
}
