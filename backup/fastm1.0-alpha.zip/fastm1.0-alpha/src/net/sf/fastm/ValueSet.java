package net.sf.fastm;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class ValueSet implements IValueSet {
	/**
	 * 
	 */
	public static final ValueSet EMPTY_VALUESET = new ValueSet();

	/**
	 * 
	 */
	public static final List ONE_VALUE_SET_LIST = new ArrayList();
	
	static { ONE_VALUE_SET_LIST.add(EMPTY_VALUESET); }

    /**
     * hold (Variable Name, Variable Value) pairs
     */
    Map varMap = null;

    /**
     * hold (DynamicPart Name, IValueList List) pairs
     */
    Map dynMap = null;

    /**
     *
     * @param name String
     * @return Object
     */
    public Object getVariable(String name) {
        if(varMap == null){
            return null;
        }

        return varMap.get(name);
    }

    /**
     *
     * @param name String
     * @param value Object
     */
    public void setVariable(String name, Object value) {
        if(varMap == null){
            varMap = new HashMap();
        }

        varMap.put(name, value);
    }

    /**
     *
     * @param name String
     * @return List
     */
    public List getDynamicValueSets(String name) {
        if(name == null || dynMap == null){
            return null;
        }

        return (List)dynMap.get(name);
    }

    /**
     *
     * @param name String
     * @param valueSets List
     */
    public void setDynamicValueSets(String name, List valueSets) {
        if(valueSets == null && dynMap != null){
            dynMap.remove(name);
        }

        if(dynMap == null){
            dynMap = new HashMap();
        }

        dynMap.put(name, valueSets);
    }

    /**
     *
     * @param name String
     * @param valueSet IValueSet
     */
    public void addDynamicValueSet(String name, IValueSet valueSet) {
        if(dynMap == null){
            dynMap = new HashMap();
        }

        List valueSets = (List)dynMap.get(name);
        if(valueSets == null){
            valueSets = new ArrayList();
            dynMap.put(name, valueSets);
        }

        valueSets.add(valueSet);
    }
}
