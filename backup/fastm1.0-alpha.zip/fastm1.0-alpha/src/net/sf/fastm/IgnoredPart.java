package net.sf.fastm;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class IgnoredPart extends BaseTemplate {
    String name = null;

    public IgnoredPart(String name) {
        this.name = name;
    }

    public String toString(IValueSet valueSet) {
        return "";
    }

    public String structure(int level){
        return printSpace(level) + "Ignored: " + name + "\n";
    }
}
