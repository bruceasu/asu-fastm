package net.sf.fastm;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>p
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class TemplateLoader implements ITemplate {
	static final Logger log = Logger.getLogger(TemplateLoader.class.getName());

    /**
     * the file to load
     */
    String fileName = null;

    /**
     * the file's last modified time
     */
    volatile long fileTime = 0;

    /**
     * the parsed result template
     */
    volatile ITemplate template = null;

    /**
     * the template file path
     * @return String
     */
    public String getFileName(){
        return fileName;
    }

    /**
     * load the template. record the file timestamp.
     *
     * @param fileName String
     * @throws IOException
     */
    public TemplateLoader(String fileName) throws IOException {
        this.fileName = fileName;
        template = Parser.parse(fileName);
        fileTime = new File(fileName).lastModified();
    }

    /**
     * each time a template is required,
     * the template loader check the file timestamp,
     * if the file timestamp is changed, the template loader reload the template.
     * if not return the current template
     *
     * @throws IOException
     * @return ITemplate
     */
    public ITemplate getTemplate() throws IOException{
        long theFiletime = new File(fileName).lastModified();
        if(fileTime != theFiletime){
        	log.info("reload mofied file " + fileName);
        	
            template = Parser.parse(fileName);
            fileTime = theFiletime;
        }

        return template;
    }

	/**
	 * 
	 * @return
	 */
    public boolean fileChanged(){
		long theFiletime = new File(fileName).lastModified();
		return fileTime != theFiletime;
    }

    /**
     * implements ITemplate
     */
    public String toString(IValueSet valueSet){
    	try{
    		return getTemplate().toString(valueSet);
    	}catch(IOException e){
    		throw new RuntimeException(e);
    	}
    }

	/**
	 * 
	 * @param level
	 * @return
	 */    
    public String structure(int level){
		try{
			return getTemplate().structure(level);
		}catch(IOException e){
			throw new RuntimeException(e);
		}
    }
}
