package net.sf.fastm;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public abstract class BaseTemplate implements ITemplate {
    /**
     * provide a
     * @return String
     */
    public String toString() {
        return toString(null);
    }

    /**
     * provide common public function to print spaces
     *
     * @param n int  the number of space to print
     * @return String the spaces
     */
    public static String printSpace(int n){
        StringBuffer buf = new StringBuffer();
        for(int i = 0; i < n; i++){
            buf.append(" ");
        }

        return buf.toString();
    }
}
