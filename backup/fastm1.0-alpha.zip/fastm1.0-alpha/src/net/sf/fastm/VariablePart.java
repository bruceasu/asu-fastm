package net.sf.fastm;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class VariablePart extends BaseTemplate {
    String name = null;

    public VariablePart(String name) {
        this.name = name;
    }

    /**
     * if the variable is set value, show the value.
     * else show the variable name iteself.
     *
     * @param valueSet IValueSet
     * @return String
     */
    public String toString(IValueSet valueSet){
        if(valueSet == null){
            return name;
        }

        Object value = valueSet.getVariable(name);

        if(value != null){
            return value.toString();
        }

        return name;
    }

    public String structure(int level){
        return printSpace(level) + "Variable: " + name + "\n";
    }
}
