package net.sf.fastm;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class DynamicPart   extends BaseTemplate {
    String name = null;

    /**
     * parts contained in this DynamicPart
     */
    List steps = null;

    /**
     * constructor
     *
     * @param name String
     */
    public DynamicPart(String name) {
        this.name = name;
    }

    /**
     *
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * get parts contained in this DynamicPart
     *
     * @return List parts contained in this DynamicPart
     */
    public List getSteps() {
        return steps;
    }

    /**
     * set parts to be contained in this DynamicPart
     *
     * @return List parts to be contained in this DynamicPart
     */
    public void setSteps(List steps) {
        this.steps = steps;
    }

    /**
     * add a part to the parts contained in this DynamicPart
     *
     * @param step ITemplate
     */
    public void addStep(ITemplate step) {
        if (steps == null) {
            steps = new ArrayList();
        }

        steps.add(step);
    }
    
    /**
     * 
     * @param valueSets
     * @return
     */
    public String toString(List stepValueSets){
    	StringBuffer buf = new StringBuffer();

		if (stepValueSets != null && !stepValueSets.isEmpty()) {
			// we may need to show this DynamicPart several times
			int nRepeats = stepValueSets.size();
			for (int j = 0; j < nRepeats; j++) {
				IValueSet v = (IValueSet) stepValueSets.get(j);
				buf.append(this.toString(v));
			}
		}
		
		return buf.toString();
    }

    /**
     *
     * @param valueSet IValueSet
     * @return String
     */
    public String toString(IValueSet valueSet) {
        if (steps == null || valueSet == null) {
            return "";
        }

        // hold all parts together to make a result string
        StringBuffer buf = new StringBuffer();

        int nSteps = steps.size();

        // depth-first iteration, add up all parts together to make a result string
        for (int i = 0; i < nSteps; i++) {
            ITemplate step = (ITemplate) steps.get(i);

            if (step instanceof DynamicPart) {
            	DynamicPart dynPart = (DynamicPart)step;
                String dynName = dynPart.getName();
                List stepValueSets = valueSet.getDynamicValueSets(dynName);

                if (stepValueSets != null && !stepValueSets.isEmpty()) {
                    // we may need to show this DynamicPart several times
                    buf.append(dynPart.toString(stepValueSets));
                }else{ // if the dynamic part can be degrated to a Variable?
                    Object value = valueSet.getVariable(dynName);
                    if(value != null){
                        buf.append(value);
                    }
                }
            }
            else { // StaticPart or VariablePart or IgnoredPart
                buf.append(step.toString(valueSet));
            }
        }

        return buf.toString();
    }

    /**
     *
     * @param level int
     * @return String
     */
    public String structure(int level) {
        StringBuffer buf = new StringBuffer();
        buf.append(printSpace(level) + "Dynamic: " + name + "\n");
        level++;

        int nSteps = steps.size();
        for (int i = 0; i < nSteps; i++) {
            ITemplate step = (ITemplate) steps.get(i);

            buf.append(step.structure(level));
        }

        return buf.toString();
    }

    /**
     *
     * @return List
     */
    public List getDynamicChildren() {
        int nSteps = steps.size();
        List dynChildren = new ArrayList();

        for (int i = 0; i < nSteps; i++) {
            Object obj = steps.get(i);

            if (obj instanceof DynamicPart) {
                dynChildren.add(obj);
            }
        }

        return dynChildren;
    }

    /**
     * find the named dynamic part width-first
     * 
     * @param name String
     * @return DynamicPart
     */
    public DynamicPart findDynmicPartWidthFirst(String name) {
        List dynChildren = getDynamicChildren();

        List queue = new LinkedList();
        queue.addAll(dynChildren);

        while (queue.size() > 0) {
            DynamicPart dynPart = (DynamicPart) queue.remove(0);

            if (dynPart.getName().equals(name)) {
                return dynPart;
            }
            else {
                queue.addAll(dynPart.getDynamicChildren());
            }
        }

        return null;
    }

	/**
	 * find the named dynamic part depth-first
	 * 
	 * @param name String
	 * @return DynamicPart
	 */
	public DynamicPart findDynmicPartDepthFirst(String name) {
		List dynChildren = getDynamicChildren();
		
		int nChildren = dynChildren.size();

		for(int i = 0; i < nChildren; i++){
			DynamicPart dynPart = (DynamicPart)dynChildren.get(i);

			if (dynPart.getName().equals(name)) {
				return dynPart;
			}else{
				// recursive
				dynPart = dynPart.findDynmicPartDepthFirst(name);
				
				if(dynPart != null){
					return dynPart;
				}
			}
		}

		return null;
	}
}
