package net.sf.fastm;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class Parser {
    /**
     * parse a file to template
     *
     * @param fileName String
     * @throws IOException
     * @return ITemplate
     */
    public static ITemplate parse(String fileName) throws IOException{
        FileReader fr = new FileReader(fileName);
        BufferedReader reader = new BufferedReader(fr);
        ITemplate template = parse(reader);
        fr.close();
        reader.close();

        return template;
    }

    /**
     * parse a BufferedReader to template
     *
     * @param reader BufferedReader
     * @throws IOException
     * @return ITemplate
     */
    public static ITemplate parse(BufferedReader reader) throws IOException{
        StringBuffer staticLines = new StringBuffer(); // hold the static lines in the file
        Stack stack = new Stack(); // store DynamicPart by level
        DynamicPart top = new DynamicPart("top"); // the DynamicPart representing the whole file

        StaticPart staticPart = null; // just a commonly used variable
        String ignoreName = null; // record the IgnoredPart name
        int lineNo = 0; // record line number

        // parse line by line, to create the Template Tree
        for(String line = reader.readLine(); line != null; line = reader.readLine()){
            lineNo++;

            // parse a line
            Token token = parseLine(line);

            // ignore block between <!-- BEGIN IGNORED: name --> <!-- END IGNORED: name -->
            if(ignoreName != null){
                // if End of the IgnoredPart, then back to normal procedure
                if(token.type == Token.EndIgnored && ignoreName.equals(token.name)){
                    ignoreName = null;
                }else{
                    continue; // ignore this line
                }
            }

            // normal line, put it to static lines buffer
            if(token.type == Token.Ordinary){
                staticLines.append(line + "\n");
                continue; // fetch next line
            }

            // code goes here, means this line contains DynamicPart definition or Variable
            if(staticLines.length() > 0){
                // create a StaticPart to hold the curret static lines in buf.
                staticPart = new StaticPart(staticLines.toString());
                top.addStep(staticPart);
                staticLines.setLength(0); // clean the static lines buf.
            }

            switch(token.type){
                case Token.BeginIgnored: // <!-- BEGIN INGNORED : name -->
                    ignoreName = token.name;
                    IgnoredPart ignoredPart = new IgnoredPart(token.name);
                    top.addStep(ignoredPart);
                    break;

                case Token.BeginDynamic: // <!-- BEGIN DYNAMIC : name -->
                    DynamicPart dynamicPart = new DynamicPart(token.name);
                    top.addStep(dynamicPart);

                    // now we enter in a new level DynamicPart, store the old
                    // use the new one as top
                    stack.push(top);
                    top = dynamicPart;

                    break;

                case Token.EndDynamic: // <!-- END DYNAMIC : name -->
                    if(!top.getName().equals(token.name)){
                        throw new IOException("line " + lineNo + ": End Dynamic: " +
                            top.getName() + " instead of " + token.name + " is expected." );
                    }

                    // back to previous level DynamicPart
                    top = (DynamicPart)stack.pop();
                    if(top == null){
                        throw new IOException("line " + lineNo + ": End Dynamic: top = null, why?");
                    }

                case Token.HasVariable: // this line contains {..}
                    List posPairs = token.posPairs;

                    // separate this line to
                    // .............{.........}.........{..........}....... etc
                    //              ^         ^         ^          ^
                    // StaticPart   VariablePart  Static   Variable   Static etc
                    if(posPairs != null){
                        int nPairs = posPairs.size();

                        int begin = 0;
                        int end = line.length() - 1;

                        for(int k = 0; k < nPairs; k++){
                            PosPair posPair = (PosPair)posPairs.get(k);

                            if(begin < posPair.begin){
                                staticPart =
                                    new StaticPart(line.substring(begin, posPair.begin));
                                top.addStep(staticPart);
                            }

                            VariablePart varPart =
                                new VariablePart(line.substring(posPair.begin, posPair.end + 1));
                            top.addStep(varPart);

                            begin = posPair.end + 1;
                        }// end for(int k = 0; k < nPairs; k++)

                        String tail = "\n";

                        if(begin < end){
                            tail = line.substring(begin, end + 1) + "\n";
                        }
                        staticPart = new StaticPart(tail);
                        top.addStep(staticPart);
                    } // end if(posPairs != null)
            }; // end switch(token.type)
        } // end for(String line = reader.readLine(); line != null; line = reader.readLine())

		DynamicPart left = (DynamicPart)stack.pop();
		if(left != null){
			throw new IOException("END DYNAMIC:" + left.getName() + " is expected but not found." );
		}

        if(staticLines.length() > 0){
            staticPart = new StaticPart(staticLines.toString());
            top.addStep(staticPart);
        }

        List steps = top.getSteps();
        if(steps != null && steps.size() == 1){
            return (ITemplate)steps.get(0);
        }

        return top;
    }

    static final Pattern commentPattern = Pattern.compile("\\s*<!--.*-->\\s*");
    static final Pattern bgeinDynPattern = Pattern.compile("\\s*BEGIN\\s*DYNAMIC\\s*:\\s*\\w*\\s*");
    static final Pattern endDynPattern = Pattern.compile("\\s*END\\s*DYNAMIC\\s*:\\s*\\w*\\s*");
    static final Pattern beginIgnPattern = Pattern.compile("\\s*BEGIN\\s*IGNORED\\s*:\\s*\\w*\\s*");
    static final Pattern endIgnPattern = Pattern.compile("\\s*END\\s*IGNORED\\s*:\\s*\\w*\\s*");

	static final Pattern bgeinDynPatternScript = Pattern.compile("\\s*//\\s*BEGIN\\s*DYNAMIC\\s*:\\s*\\w*\\s*");
	static final Pattern endDynPatternScript = Pattern.compile("\\s*//\\s*END\\s*DYNAMIC\\s*:\\s*\\w*\\s*");

    static final Pattern patternGroup[] = {
        bgeinDynPattern,
        endDynPattern,
        beginIgnPattern,
        endIgnPattern,
    };

    static final int typeGroup[] = {
        Token.BeginDynamic,
        Token.EndDynamic,
        Token.BeginIgnored,
        Token.EndIgnored,
    };

    /**
     *
     * @param line String
     * @return Token
     */
    public static Token parseLine(String line){
        Token token = new Token();

        // if this line is a Comment Definition for DynamicPart etc
        if(commentPattern.matcher(line).matches()){
            int commentBeginPos = line.indexOf("<!--") + "<!--".length();
            int commentEndPos = line.indexOf("-->", commentBeginPos);

            String tag = line.substring(commentBeginPos, commentEndPos).trim();

            int nPatterns = patternGroup.length;
            for(int i = 0; i < nPatterns; i++){
                Pattern pattern = patternGroup[i];
                if(pattern.matcher(tag).matches()){
                    token.type = typeGroup[i];
                    break;
                }
            }

            if(token.type > Token.Begin){ // valid
                int commaPos = tag.indexOf(":");
                token.name = tag.substring(commaPos + 1).trim();
            }

            return token;
        }

		// if this line is a JavaScript Comment Definition for DynamicPart etc
		if(bgeinDynPatternScript.matcher(line).matches()){
			token.type = Token.BeginDynamic;
			int commaPos = line.indexOf(":");
			token.name = line.substring(commaPos + 1).trim();
			
			return token;
		}

		if(endDynPatternScript.matcher(line).matches()){
			token.type = Token.EndDynamic;
			int commaPos = line.indexOf(":");
			token.name = line.substring(commaPos + 1).trim();

			return token;
		}

        // let's see if this line contains variables -- {...}
        int begin = 0;
        List posPairs = null;

        // separate this line to
        // .............{.........}.........{..........}....... etc
        //              ^         ^         ^          ^
        //              begin     end       begin      end
        while(true){
            int lBracketPos = line.indexOf("{", begin);
            if(lBracketPos < 0) break;

            int rBracketPos = line.indexOf("}", lBracketPos);
            if(rBracketPos < 0) break;

            begin = rBracketPos + 1;

            if(posPairs == null){
               posPairs = new ArrayList();
            }

            PosPair posPair = new PosPair();
            posPair.begin = lBracketPos;
            posPair.end = rBracketPos;

            posPairs.add(posPair);
        }

        if(posPairs != null){
            token.type = Token.HasVariable;
            token.posPairs = posPairs;
        }

        return token;
    }

    public static class Token {
        static final int Begin = 10;
        static final int End = 20;
        static final int Dynamic = 1;
        static final int Ingnored = 2;

        /**
         * indicate the string is like
         * <!-- BEGIN DYNAMIC : name -->
         */
        static final int BeginDynamic = Begin + Dynamic;

        /**
         * indicate the string is like
         * <!-- END DYNAMIC : name -->
         */
        static final int EndDynamic = End + Dynamic;

        /**
         * indicate the string is like
         * <!-- BEGIN IGNORED : name -->
         */
        static final int BeginIgnored = Begin + Ingnored;

        /**
         * indicate the string is like
         * <!-- BEGIN IGNORED : name -->
         */
        static final int EndIgnored = End + Ingnored;

        /**
         * indicate the string is like
         * ....{...}....{....}....
         */
        static final int HasVariable = 5;

        /**
         * indicate this is a normal static string
         */
        static final int Ordinary = 0;

        /**
         * to indicate if this line is a comment definition,
         * or has variable, or just a static line
         */
        int type = 0;

        /**
         * DynamicPart or IngnoredPart name
         */
        String name = null;

        /**
         * variables {...} positions
         */
        List posPairs = null;
    };

   /**
    * to record a word position in a String.
    * for example,
    * .............{.........}.........{..........}....... etc
    *              ^         ^         ^          ^
    *              begin     end       begin      end
    */
    static class PosPair{
        int begin = 0;
        int end = 0;
    };
}
