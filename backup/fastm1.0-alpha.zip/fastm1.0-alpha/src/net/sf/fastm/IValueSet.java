package net.sf.fastm;

import java.util.List;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public interface IValueSet {
    /**
     * get value for variable
     *
     * @param name String variable name, like {A_MESSAGE}
     * @return Object the variable value
     */
    public Object getVariable(String name);

    /**
     * set value for variable
     *
     * @param name String variable name, like {A_MESSAGE}
     * @return Object the variable value
     */
    public void setVariable(String name, Object value);

    /**
     * get IValueSet List for a DynamicPart
     *
     * @param name String the DynamicPart name, like "mySimpleRow"
     * @return List the type is List to support loops.
     *    if return null or empty list,
     *    it means this DynamicPart will not be displayed
     */
    public List getDynamicValueSets(String name);

    /**
     * set IValueSet List for a DynamicPart
     *
     * @param name String the DynamicPart name, like "mySimpleRow"
     * @param valueSets List the type is List to support loops.
     *    if set null or empty list,
     *    it means this DynamicPart will not be displayed
     */
    public void setDynamicValueSets(String name, List valueSets);

    /**
     * add a IValueSet to the list of the DynamicPart
     *
     * @param name String the DynamicPart name, like "mySimpleRow"
     * @param valueSet IValueSet the IValueSet to be added
     */
    public void addDynamicValueSet(String name, IValueSet valueSet);
}
