package net.sf.fastm;

import java.util.List;
import java.util.ArrayList;

/**
 * <p>Title: Fast Template</p>
 * <p>Description: Fast Template For XML File (Using XML Comment as Tag)</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Wang Hailong
 * @version 1.0
 */

public class Stack {
    List list = null;

    public Object pop(){
        if(list == null){
            return null;
        }

        int last = list.size() - 1;
        if(last >= 0){
            return list.remove(last);
        }

        return null;
    }

    public void push(Object object){
        if(list == null){
            list = new ArrayList();
        }

        list.add(object);
    }
}
